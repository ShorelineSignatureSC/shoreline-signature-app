import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "../styles.css";
import Home from "./Home";

// Account emails (invites, confirmations, password resets) link back to the site root — hand them to the portal.
if (/(confirmation|recovery|invite|email_change)_token=/.test(window.location.hash)) {
  window.location.replace("/portal/" + window.location.hash);
} else {
  createRoot(document.getElementById("root")!).render(
    <StrictMode>
      <Home />
    </StrictMode>,
  );
}

// Register the installable app worker only on secure production origins.
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch((error) => {
      console.warn("Shoreline app service worker unavailable:", error);
    });
  });
}
