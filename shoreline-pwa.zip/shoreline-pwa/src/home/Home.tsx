import { Fragment, useEffect, useState } from "react";
import {
  ArrowRight,
  AtSign,
  BedDouble,
  Camera,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Flower2,
  Lock,
  Mail,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  Wind,
  X,
} from "lucide-react";
import { BEDROOM_OPTIONS, DEFAULT_PRICING, EMAIL, PHONE_DISPLAY, PHONE_TEL, type Pricing } from "../../shared/constants";
import BookingForm from "./BookingForm";

export type PublicConfig = { pricing: Pricing; squareUrl: string; depositNote: string };

const NAV = [
  { label: "Services", id: "services" },
  { label: "Rentals & Beach Homes", id: "properties" },
  { label: "About", id: "about" },
  { label: "The Difference", id: "difference" },
  { label: "Contact", id: "contact" },
];

const SERVICES = [
  { icon: Sparkles, title: "Signature Turnover Cleaning", desc: "Hotel-grade cleaning, every time. Dust-free baseboards to polished fixtures.", points: "Bedrooms • Baths • Kitchen • Living" },
  { icon: Wind, title: "Linen & Restocking Program", desc: "Premium linens laundered, pressed, and staged. Consumables tracked.", points: "Parachute-grade linens • Inventory" },
  { icon: Flower2, title: "Welcome Touch Staging", desc: "First impression magic. Styled entry, curated scents, and guest-ready lighting.", points: "Styling • Scent • Ambiance" },
  { icon: ClipboardCheck, title: "Property Inspections & Reports", desc: "24 photo-verified inspection after each turnover. Damage logged instantly.", points: "Photo report • Maintenance flags" },
  { icon: MessageCircle, title: "Concierge & Guest Support", desc: "On-call guest messaging, mid-stay touch-ups, and lost-and-found handling.", points: "Messaging • Mid-stay cleans" },
  { icon: Sparkles, title: "Deep Clean & Seasonal Refresh", desc: "Quarterly deep cleans, pre-summer opening and winterization prep.", points: "Appliances • Windows • Exteriors" },
];

const TIER_COPY: Record<string, string> = {
  studio: "Efficient, spotless turnovers for studios and efficiency condos — fresh linens, sparkling bath, and a ready-to-relax welcome.",
  "1": "Complete one-bedroom turnovers with detailed kitchen and bath cleaning, linen service, and guest-ready staging.",
  "2": "Two-bedroom condos and cottages cleaned top to bottom, beds dressed, towels folded, and every room prepared for arrival.",
  "3": "Larger family rentals turned over with a full team — detailed cleaning, laundry and restocking, and welcome touches throughout.",
  "4": "Spacious beach homes with multiple baths, outdoor living, and high guest counts. Priced to your property's size and needs.",
  "5": "Our most comprehensive turnover for large oceanfront homes — full-team cleaning, linen program, staging, and inspection.",
};

const IMG = "/.netlify/images?url=/img/coastal-living.png&fm=webp";

function GoldRule({ light = false }: { light?: boolean }) {
  return (
    <div className="mt-5 flex items-center gap-3 max-w-[220px]" aria-hidden="true">
      <span className={`h-px flex-1 ${light ? "bg-[var(--gold)]/60" : "bg-[var(--gold)]"}`} />
      <span className="h-2 w-2 rotate-45 bg-[var(--gold)]" />
      <span className={`h-px flex-1 ${light ? "bg-[var(--gold)]/60" : "bg-[var(--gold)]"}`} />
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("top");
  const [config, setConfig] = useState<PublicConfig | null>(null);
  const [preset, setPreset] = useState<{ bedrooms: string; requestType: "booking" | "quote"; n: number } | null>(null);

  useEffect(() => {
    fetch("/api/public/config")
      .then((r) => (r.ok ? r.json() : null))
      .then((c) => setConfig(c ?? { pricing: DEFAULT_PRICING, squareUrl: "", depositNote: "" }))
      .catch(() => setConfig({ pricing: DEFAULT_PRICING, squareUrl: "", depositNote: "" }));
  }, []);

  const go = (id: string) => {
    setActive(id);
    try {
      history.replaceState(null, "", `#${id}`);
    } catch {
      /* ignore */
    }
    const smooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    document.getElementById(id)?.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
    setMenuOpen(false);
  };

  const chooseTier = (bedrooms: string, quote: boolean) => {
    setPreset({ bedrooms, requestType: quote ? "quote" : "booking", n: Date.now() });
    go("contact");
  };

  const pricing = config?.pricing ?? null;

  return (
    <div className="min-h-screen w-full bg-[var(--bg)] text-[var(--ink)] overflow-x-clip">
      <div className="sticky top-0 z-50">
        <div className="bg-[var(--navy)] text-white text-[11px] tracking-[0.14em] uppercase border-b border-[var(--gold)]/70">
          <div className="mx-auto max-w-[1280px] px-6 lg:px-10 h-9 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <span className="opacity-70 hidden sm:inline">Direct line for owners & managers —</span>
              <a href={`mailto:${EMAIL}`} className="font-medium tracking-normal normal-case text-[13px] hover:text-[var(--gold)] transition hidden sm:inline">
                {EMAIL}
              </a>
              <span className="hidden sm:inline opacity-30">•</span>
              <a href={`tel:${PHONE_TEL}`} className="font-medium tracking-normal normal-case text-[13px] hover:text-[var(--gold)] transition">
                {PHONE_DISPLAY}
              </a>
            </div>
            <div className="flex items-center gap-6">
              <span className="hidden md:inline opacity-80">Licensed & Insured • Grand Strand SC</span>
              <a href="/portal/" className="flex items-center gap-1.5 text-[var(--gold)] hover:text-white transition font-semibold">
                <Lock size={11} /> Team Login
              </a>
            </div>
          </div>
        </div>
        <header
          className="backdrop-blur-xl border-b border-[var(--line)]"
          style={{ background: "color-mix(in srgb, var(--surface) 88%, transparent)", backdropFilter: "blur(18px)", WebkitBackdropFilter: "blur(18px)" }}
        >
          <div className="mx-auto max-w-[1280px] px-6 lg:px-10 h-[72px] flex items-center justify-between">
            <button
              onClick={() => {
                setActive("top");
                try {
                  history.replaceState(null, "", "#top");
                } catch {
                  /* ignore */
                }
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="flex items-center gap-3 text-left group"
              aria-label="Shoreline Signature Services — back to top"
            >
              <img src="/.netlify/images?url=/img/logo-emblem.png&w=92&h=92&fm=webp" alt="" aria-hidden="true" width={46} height={46} className="shrink-0 rounded-full ring-1 ring-[var(--gold)]/60" />
              <span className="leading-[0.95]">
                <span className="block font-display font-[700] tracking-[0.2em] text-[17px] text-[var(--ink)]">SHORELINE</span>
                <span className="block font-[500] tracking-[0.22em] text-[10px] text-[var(--gold-dark)] -mt-[1px]">SIGNATURE SERVICES</span>
              </span>
            </button>
            <nav className="hidden lg:flex items-center gap-7" aria-label="Main navigation">
              {NAV.map((n) => (
                <button
                  key={n.id}
                  onClick={() => go(n.id)}
                  className={`text-[12px] tracking-[0.08em] uppercase font-[500] relative transition-opacity text-[var(--ink)] ${active === n.id ? "opacity-100" : "opacity-70 hover:opacity-100"} after:absolute after:left-0 after:-bottom-1 after:h-[1px] after:transition-all after:bg-[var(--gold)] ${active === n.id ? "after:w-full" : "after:w-0 hover:after:w-full"}`}
                >
                  {n.label}
                </button>
              ))}
            </nav>
            <div className="hidden lg:flex items-center gap-4">
              <button
                onClick={() => go("contact")}
                className="h-10 px-6 bg-[var(--gold)] text-[#0a2342] text-[12px] tracking-[0.14em] uppercase font-semibold hover:bg-[var(--navy)] hover:text-[var(--gold)] transition flex items-center gap-2"
              >
                Request a Quote <ArrowRight size={14} />
              </button>
            </div>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              aria-expanded={menuOpen}
              aria-label={menuOpen ? "Close menu" : "Open menu"}
              className="lg:hidden h-10 w-10 grid place-items-center border border-[var(--line-strong)] text-[var(--ink)]"
            >
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
          {menuOpen && (
            <div className="lg:hidden border-t border-[var(--line)] bg-[var(--surface)] px-6 py-6 space-y-5 max-h-[calc(100vh-110px)] overflow-y-auto">
              <div className="flex flex-col gap-4">
                {[...NAV.slice(0, 4), { label: "Service Area", id: "service-area" }, NAV[4]].map((n) => (
                  <button
                    key={n.id}
                    onClick={() => go(n.id)}
                    className={`text-left text-[22px] font-[500] tracking-[-0.02em] font-display text-[var(--ink)] ${active === n.id ? "opacity-100" : "opacity-70"}`}
                  >
                    {n.label}
                  </button>
                ))}
              </div>
              <button onClick={() => go("contact")} className="w-full h-12 bg-[var(--navy)] text-white text-[12px] tracking-[0.14em] uppercase font-semibold">
                Request a Quote
              </button>
              <a
                href="/portal/"
                className="w-full h-12 border border-[var(--gold)] text-[var(--ink)] text-[12px] tracking-[0.14em] uppercase font-semibold flex items-center justify-center gap-2"
              >
                <Lock size={14} className="text-[var(--gold)]" /> Owner & Employee Login
              </a>
              <div className="text-[12px] opacity-60 flex items-center gap-2 flex-wrap">
                <a href={`mailto:${EMAIL}`} className="hover:underline">{EMAIL}</a>
                <span>•</span>
                <a href={`tel:${PHONE_TEL}`} className="hover:underline">{PHONE_DISPLAY}</a>
              </div>
            </div>
          )}
        </header>
      </div>

      {/* HERO */}
      <section className="relative overflow-hidden" id="top">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[var(--navy)]" />
          <div className="absolute inset-0 bg-gradient-to-br from-[#0A2342] via-[#0f2d55] to-[#16396a]" />
          <div
            className="absolute inset-0 opacity-40"
            style={{ background: "radial-gradient(800px 400px at 75% 20%, rgba(198,166,106,0.22), transparent 60%), radial-gradient(600px 300px at 10% 80%, rgba(237,230,214,0.12), transparent 60%)" }}
          />
          <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "linear-gradient(rgba(255,255,255,0.8) 1px, transparent 1px)", backgroundSize: "100% 24px" }} />
        </div>
        <div className="relative mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28 grid lg:grid-cols-[1.15fr_0.85fr] gap-10 items-center">
          <div className="text-white">
            <img src="/.netlify/images?url=/img/logo-emblem.png&w=192&h=192&fm=webp" alt="Shoreline Signature Services logo" width={96} height={96} className="rounded-full ring-2 ring-[var(--gold)] shadow-[0_0_40px_rgba(198,166,106,0.35)] mb-8" />
            <div className="flex w-fit items-center gap-2 px-3 py-1 rounded-full bg-[var(--gold)]/10 border border-[var(--gold)]/60 text-[var(--gold-light)] text-[11px] tracking-[0.16em] uppercase mb-8">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--gold)] animate-pulse" />
              Now booking Fall & Winter turnovers
            </div>
            <h1 className="text-[42px] sm:text-[56px] lg:text-[72px] leading-[0.92] tracking-[-0.03em] font-[600] max-w-[12ch]">
              The Signature of a <span className="font-script font-[400] text-[var(--gold)] text-[1.08em] leading-[1.1] inline-block pr-2">Perfect Stay.</span>
            </h1>
            <p className="mt-6 text-[17px] leading-[1.6] max-w-[48ch] text-white/80 font-light">
              Luxury turnover, cleaning & property care for Myrtle Beach’s finest vacation rentals — from studio condos to 5-bedroom beach homes. Hotel-grade standards, photo-verified results, zero stress for owners.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button
                onClick={() => go("contact")}
                className="h-[52px] px-8 bg-[var(--gold)] text-[#0a2342] text-[13px] tracking-[0.12em] uppercase font-semibold hover:bg-white transition flex items-center gap-2"
              >
                Book Your Signature Service <ArrowRight size={16} />
              </button>
              <button onClick={() => go("properties")} className="h-[52px] px-8 border border-[var(--gold)]/70 text-white text-[13px] tracking-[0.12em] uppercase font-medium hover:bg-white/10 transition">
                View Services & Pricing
              </button>
            </div>
            <div className="mt-12 flex flex-wrap gap-x-8 gap-y-3 text-[11px] tracking-[0.16em] uppercase text-white/60 border-t border-white/10 pt-6 max-w-[560px]">
              <span className="flex items-center gap-2"><ShieldCheck size={14} className="text-[var(--gold)]" /> Licensed & Insured</span>
              <span className="flex items-center gap-2"><Star size={14} className="text-[var(--gold)]" /> 5-Star Rated</span>
              <span className="flex items-center gap-2"><MapPin size={14} className="text-[var(--gold)]" /> Serving Grand Strand</span>
            </div>
          </div>
          <div className="relative lg:ml-auto w-full max-w-[420px]">
            <div className="bg-[var(--surface)] rounded-[2px] shadow-[0_32px_80px_-16px_rgba(0,0,0,0.4)] overflow-hidden border border-white/10">
              <div className="p-7">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-[11px] tracking-[0.18em] uppercase opacity-50">Signature Standard</div>
                    <div className="mt-1 font-display text-[22px] leading-none">Turnover Complete</div>
                  </div>
                  <div className="h-9 w-9 rounded-full bg-[var(--gold)]/15 grid place-items-center text-[var(--gold-dark)]">
                    <CheckCircle2 size={18} />
                  </div>
                </div>
                <div className="mt-6 grid grid-cols-2 gap-3">
                  <div className="bg-[var(--surface-soft)] p-3">
                    <div className="text-[10px] tracking-[0.16em] uppercase opacity-60">Photos</div>
                    <div className="mt-1 text-[13px] font-medium">Before & after</div>
                  </div>
                  <div className="bg-[var(--surface-soft)] p-3">
                    <div className="text-[10px] tracking-[0.16em] uppercase opacity-60">Checklist</div>
                    <div className="mt-1 text-[13px] font-medium">87-point standard</div>
                  </div>
                </div>
                <div className="mt-4 h-[120px] rounded-[2px] overflow-hidden relative bg-[var(--sand-2)]">
                  <img src={`${IMG}&w=800&h=300&fit=cover`} alt="Freshly staged coastal living room with crisp ivory linens" className="w-full h-full object-cover" loading="eager" />
                  <span className="absolute bottom-2 left-2 bg-[var(--navy)]/85 text-white text-[9px] tracking-[0.2em] uppercase px-2 py-1">Guest-ready</span>
                </div>
                <div className="mt-5 flex items-center gap-2 text-[12px]">
                  <div className="h-7 w-7 rounded-full bg-[var(--navy)] text-white grid place-items-center text-[11px]">S</div>
                  <span className="opacity-70">Inspected & signed off by your lead</span>
                </div>
              </div>
              <div className="h-1 w-full bg-gradient-to-r from-[var(--gold)] to-[var(--navy)]" />
            </div>
            <div className="absolute left-4 -bottom-6 sm:-left-6 hidden sm:flex items-center gap-3 bg-white text-[var(--navy)] px-4 py-3 shadow-xl border border-black/5 max-w-[90%]">
              <div className="h-8 w-8 rounded-full bg-[var(--navy)] text-white grid place-items-center">
                <Clock size={14} />
              </div>
              <div className="leading-tight">
                <div className="text-[11px] tracking-[0.14em] uppercase opacity-60">Turnovers</div>
                <div className="text-[13px] font-semibold">Same-day available</div>
              </div>
            </div>
          </div>
        </div>
        <div className="relative">
          <svg viewBox="0 0 1440 72" preserveAspectRatio="none" className="wave-divider bg-transparent text-[var(--bg)]" aria-hidden="true">
            <path d="M0,40 C240,72 480,0 720,24 C960,48 1200,72 1440,32 L1440,72 L0,72 Z" fill="currentColor" />
          </svg>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28 scroll-mt-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <div className="text-[11px] tracking-[0.22em] uppercase text-[var(--gold-dark)] font-semibold">Signature Services</div>
            <h2 className="mt-3 text-[36px] sm:text-[48px] leading-[0.95] max-w-[14ch]">Every detail, handled like a 5-star hotel.</h2>
            <GoldRule />
          </div>
          <p className="max-w-[40ch] text-[15px] leading-[1.7] opacity-70">
            Built for second-home owners, Airbnb Superhosts and boutique managers who refuse to compromise on guest experience.
          </p>
        </div>
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-[1px] bg-[var(--line-strong)] border border-[var(--line-strong)]">
          {SERVICES.map((c) => (
            <button key={c.title} onClick={() => go("contact")} className="text-left group bg-[var(--surface)] p-8 lg:p-10 hover:bg-[var(--surface-soft)] transition-colors">
              <div className="h-11 w-11 border border-[var(--gold)] text-[var(--gold-dark)] grid place-items-center group-hover:border-[var(--navy)] group-hover:bg-[var(--navy)] group-hover:text-[var(--gold)] transition-colors">
                <c.icon size={18} />
              </div>
              <h3 className="mt-6 text-[20px] leading-[1.15]">{c.title}</h3>
              <p className="mt-3 text-[14px] leading-[1.6] opacity-70 min-h-[44px]">{c.desc}</p>
              <div className="mt-6 pt-6 border-t border-[var(--line)] flex items-center justify-between">
                <span className="text-[11px] tracking-[0.14em] uppercase opacity-50">{c.points}</span>
                <ArrowRight size={14} className="opacity-30 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* PROPERTY SIZES */}
      <section id="properties" className="bg-[var(--surface-soft)] border-y border-[var(--line)] scroll-mt-28">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28">
          <div className="grid lg:grid-cols-[1fr_1fr] gap-10 items-end">
            <div>
              <div className="text-[11px] tracking-[0.22em] uppercase text-[var(--gold-dark)] font-semibold">Vacation Rentals & Beach Homes</div>
              <h2 className="mt-3 text-[36px] sm:text-[48px] leading-[0.95] max-w-[16ch]">From studio condos to 5-bedroom beach homes.</h2>
            <GoldRule />
            </div>
            <p className="text-[15px] leading-[1.7] opacity-70 max-w-[56ch]">
              Every property receives a professional vacation rental turnover: detailed cleaning of every room, fresh linen service, welcome staging, and complete
              property preparation so each guest arrives to a home that feels composed, comfortable, and five-star ready.
            </p>
          </div>

          <div className="mt-10 flex flex-wrap gap-2">
            {["Vacation rental turnovers", "Detailed cleaning", "Linen services", "Welcome staging", "Guest-arrival preparation", "Photo inspection"].map((t) => (
              <span key={t} className="inline-flex items-center gap-2 px-3 py-1.5 bg-[var(--surface)] border border-[var(--line-strong)] text-[11px] tracking-[0.14em] uppercase">
                <CheckCircle2 size={12} className="text-[var(--gold)]" /> {t}
              </span>
            ))}
          </div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-[1px] bg-[var(--line-strong)] border border-[var(--line-strong)]">
            {BEDROOM_OPTIONS.map((b) => {
              const price = pricing?.[b.value];
              const quote = b.quoteOnly || !price;
              return (
                <div key={b.value} className={`relative p-8 flex flex-col ${b.quoteOnly ? "bg-[var(--navy)] text-white" : "bg-[var(--surface)]"}`}>
                  {b.quoteOnly && (
                    <span className="absolute top-0 right-0 bg-[var(--gold)] text-[var(--navy)] text-[10px] tracking-[0.18em] uppercase font-semibold px-3 py-1">Custom Quote</span>
                  )}
                  <div className="flex items-center gap-3">
                    <div className={`h-11 w-11 grid place-items-center border ${b.quoteOnly ? "border-white/20 text-[var(--gold)]" : "border-[var(--line-strong)]"}`}>
                      <BedDouble size={18} />
                    </div>
                    <div className={`text-[11px] tracking-[0.18em] uppercase ${b.quoteOnly ? "text-white/60" : "opacity-50"}`}>{b.short}</div>
                  </div>
                  <h3 className="mt-6 text-[22px] leading-[1.1]">{b.value === "studio" ? "Studio / Efficiency" : b.quoteOnly ? `${b.value}-Bedroom Beach Homes` : `${b.value}-Bedroom Properties`}</h3>
                  <p className={`mt-3 text-[14px] leading-[1.6] flex-1 ${b.quoteOnly ? "text-white/75" : "opacity-70"}`}>{TIER_COPY[b.value]}</p>
                  <div className={`mt-6 pt-6 border-t flex items-end justify-between gap-4 ${b.quoteOnly ? "border-white/10" : "border-[var(--line)]"}`}>
                    <div>
                      <div className={`text-[10px] tracking-[0.18em] uppercase ${b.quoteOnly ? "text-white/50" : "opacity-50"}`}>{quote ? "Pricing" : "Turnovers from"}</div>
                      <div className="mt-1 font-display text-[26px] leading-none min-h-[26px]">
                        {pricing === null ? <span className="opacity-30">—</span> : quote ? "Request a Quote" : `$${price}`}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => chooseTier(b.value, quote)}
                    className={`mt-6 h-11 w-full text-[12px] tracking-[0.14em] uppercase font-semibold flex items-center justify-center gap-2 transition ${
                      b.quoteOnly ? "bg-[var(--gold)] text-[var(--navy)] hover:bg-white" : "bg-[var(--navy)] text-white hover:bg-[var(--navy-2)]"
                    }`}
                  >
                    {quote ? "Request a Quote" : "Book This Size"} <ArrowRight size={14} />
                  </button>
                </div>
              );
            })}
          </div>
          <p className="mt-6 text-[12px] leading-[1.6] opacity-60 max-w-[80ch]">
            4- and 5-bedroom beach home pricing varies with property size, condition, number of baths, and cleaning requirements — we’ll review your home and send a
            personalized quote. Starting prices are for standard turnovers; deep cleans, laundry, and add-on services are quoted with your booking confirmation.
          </p>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="bg-[var(--surface)] border-b border-[var(--line)] scroll-mt-28">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28 grid lg:grid-cols-[1.05fr_0.95fr] gap-12 lg:gap-20 items-start">
          <div>
            <div className="text-[11px] tracking-[0.22em] uppercase text-[var(--gold-dark)] font-semibold">Why Shoreline</div>
            <h2 className="mt-4 text-[34px] sm:text-[44px] leading-[0.96]">We treat your beach home like our own front porch.</h2>
            <GoldRule />
            <div className="mt-6 border-l-2 pl-5 border-[var(--gold)]">
              <div className="text-[11px] tracking-[0.22em] uppercase font-semibold text-[var(--gold)]">Family-Owned & Operated</div>
              <p className="mt-2 text-[15px] leading-[1.6] font-display italic text-[var(--ink)]">
                Led by Owners & Operators Mr. Y.Z. Tucker Jr. & Mrs. Kristin Tucker — committed to white-glove standards across the Grand Strand.
              </p>
            </div>
            <div className="mt-8 space-y-5 text-[15px] leading-[1.8] opacity-75">
              <p>Shoreline Signature Services was founded on one belief: a guest’s first breath inside your home should feel intentional. Not just clean — composed.</p>
              <p>
                We’re a small, owner-led team based in Surfside Beach. No franchise crews, no rotating strangers. The same trained specialists who know where your owner’s closet key
                hides and how you like the throw pillows angled.
              </p>
              <p>
                Every turnover follows <span className="font-semibold text-[var(--ink)]">The Shoreline Checklist — 87 Point Signature Standard</span>. It’s printed, laminated, and
                signed off in the field. Owners get the photos to prove it.
              </p>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-[1px] bg-[var(--line-strong)] border border-[var(--line-strong)] max-w-[520px]">
              {[
                { k: "100%", v: "5-Star Ready" },
                { k: "Same-Day", v: "Turnovers" },
                { k: "Photo", v: "Verified Results" },
              ].map((c) => (
                <div key={c.v} className="bg-[var(--surface-soft)] p-5">
                  <div className="font-display text-[22px] sm:text-[26px] leading-none">{c.k}</div>
                  <div className="mt-2 text-[11px] tracking-[0.14em] uppercase opacity-60">{c.v}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <figure className="relative border border-[var(--line-strong)] bg-[var(--sand-2)] overflow-hidden">
              <img
                src={`${IMG}&w=1200&h=760&fit=cover`}
                srcSet={`${IMG}&w=640&h=405&fit=cover 640w, ${IMG}&w=1200&h=760&fit=cover 1200w`}
                sizes="(min-width: 1024px) 540px, 100vw"
                alt="Beautifully staged coastal vacation rental living room with ivory linens and ocean views"
                className="w-full aspect-[16/10] object-cover"
                loading="lazy"
              />
              <figcaption className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0A2342]/85 to-transparent text-white px-5 pt-10 pb-4 flex items-end justify-between gap-3">
                <span className="font-display italic text-[18px]">Guest-ready, every arrival.</span>
                <span className="text-[10px] tracking-[0.18em] uppercase text-[var(--gold)]">Signature Standard</span>
              </figcaption>
            </figure>
            <div className="border border-[var(--line-strong)] bg-[var(--bg)]">
              <div className="p-7 flex items-center justify-between">
                <h3 className="text-[18px]">The Shoreline Checklist</h3>
                <span className="text-[11px] tracking-[0.18em] uppercase px-2 py-1 bg-[var(--gold)] text-[#0a2342] font-semibold">87 Points</span>
              </div>
              <div className="h-[1px] bg-[var(--line-strong)]" />
              <div className="p-7 grid grid-cols-1 sm:grid-cols-2 gap-4 text-[13px]">
                {[
                  "Kitchen appliance interiors",
                  "Baseboards & vents",
                  "Under beds & sofas",
                  "Light switches sanitized",
                  "Owner’s closet secured",
                  "HVAC filter check",
                  "Sliding doors tracked",
                  "Grill & balcony sweep",
                  "Coffee & consumables",
                  "Welcome lighting set",
                  "Linens triple-checked",
                  "Trash & recycling out",
                ].map((c) => (
                  <div key={c} className="flex items-start gap-2">
                    <CheckCircle2 size={14} className="mt-0.5 text-[var(--gold-dark)] shrink-0" />
                    <span className="opacity-80 leading-[1.4]">{c}</span>
                  </div>
                ))}
              </div>
              <div className="px-7 pb-7">
                <div className="bg-[var(--navy)] text-white p-4 flex gap-3 items-start">
                  <Camera size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
                  <p className="text-[12px] leading-[1.5] opacity-90">Every turnover includes timestamped before-and-after photos and a completion report, reviewed by ownership.</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-[var(--sand-2)] text-[#0a2342] p-5 border border-[var(--sand-3)]">
                <div className="text-[11px] tracking-[0.16em] uppercase opacity-60">Response Time</div>
                <div className="mt-2 font-display text-[20px] sm:text-[22px]">Under 2 hours</div>
                <div className="mt-1 text-[12px] opacity-60">Owner messages 7am-9pm</div>
              </div>
              <div className="bg-[var(--navy)] text-white p-5">
                <div className="text-[11px] tracking-[0.16em] uppercase opacity-60">Guest Promise</div>
                <div className="mt-2 font-display text-[20px] sm:text-[22px]">Zero surprises</div>
                <div className="mt-1 text-[12px] opacity-70">If it’s not perfect, we return same-day</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DIFFERENCE */}
      <section id="difference" className="mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28 scroll-mt-28">
        <div className="max-w-[720px]">
          <div className="text-[11px] tracking-[0.22em] uppercase text-[var(--gold-dark)] font-semibold">The Difference</div>
          <h2 className="mt-4 text-[36px] sm:text-[52px] leading-[0.94]">Detail. Dependability. Documentation.</h2>
            <GoldRule />
          <p className="mt-5 text-[16px] leading-[1.7] opacity-70">Three pillars other cleaners skip. We built our entire company around them.</p>
        </div>
        <div className="mt-14 grid lg:grid-cols-3 gap-[1px] bg-[var(--line-strong)] border border-[var(--line-strong)]">
          {[
            { title: "Detail", sub: "We notice what guests feel", desc: "Toothbrush holders polished inside, remote batteries checked, ocean-view windows streak-free. 87 points because 86 misses something.", accent: "01" },
            { title: "Dependability", sub: "Same team, same standard", desc: "No random crews. Your home gets the same 2-person lead team who knows your preferences, gate codes, and owner closet protocol.", accent: "02" },
            { title: "Documentation", sub: "You see everything", desc: "Timestamped photo report, linen counts, damage notes, and restock list sent before the next guest even parks.", accent: "03" },
          ].map((c) => (
            <div key={c.title} className="bg-[var(--surface)] p-8 lg:p-10 relative overflow-hidden group">
              <div className="absolute right-6 top-6 text-[64px] font-display leading-none opacity-[0.06] group-hover:opacity-[0.09] transition">{c.accent}</div>
              <div className="relative">
                <div className="h-10 w-10 rounded-full bg-[var(--navy)] text-white grid place-items-center text-[11px] tracking-[0.16em]">{c.accent}</div>
                <h3 className="mt-6 text-[26px]">{c.title}</h3>
                <div className="mt-1 text-[12px] tracking-[0.14em] uppercase opacity-50">{c.sub}</div>
                <p className="mt-4 text-[14px] leading-[1.7] opacity-70">{c.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-12 border border-[var(--line-strong)] overflow-x-auto max-w-full">
          <div className="min-w-[680px] w-full grid grid-cols-[1.2fr_1fr_1fr] divide-x divide-[var(--line)]">
            <div className="p-5 text-[11px] tracking-[0.16em] uppercase opacity-50">Standard</div>
            <div className="p-5 text-[11px] tracking-[0.16em] uppercase opacity-40">Typical Cleaner</div>
            <div className="p-5 text-[11px] tracking-[0.16em] uppercase bg-[var(--navy)] text-white">Shoreline Signature</div>
            {[
              ["Cleaning Checklist", "Basic", "87-Point Laminated & Signed"],
              ["Photo Report", "None or on request", "Before & After Photos Every Turnover"],
              ["Team", "Rotating staff", "Same Lead Team, Owner-Trained"],
              ["Linen Handling", "Guest left to wash", "Professional Launder & Press"],
              ["Response", "Next day", "< 2 Hours, 7 Days"],
            ].map((c) => (
              <Fragment key={c[0]}>
                <div className="p-4 text-[13px] font-medium bg-[var(--surface-soft)] border-t border-[var(--line)]">{c[0]}</div>
                <div className="p-4 text-[13px] opacity-60 border-t border-[var(--line)]">{c[1]}</div>
                <div className="p-4 text-[13px] font-medium bg-[var(--surface)] flex items-center gap-2 border-t border-[var(--line)]">
                  <CheckCircle2 size={14} className="text-[var(--gold-dark)] shrink-0" />
                  {c[2]}
                </div>
              </Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-[var(--navy)] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: "radial-gradient(white 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
        <div className="relative mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28">
          <div className="flex flex-wrap justify-between gap-6 items-end">
            <h2 className="text-[32px] sm:text-[44px] leading-[0.95] max-w-[14ch]">Hosts sleep better when we <span className="text-[var(--gold)] italic">hold the keys.</span></h2>
            <div className="flex items-center gap-2 text-[11px] tracking-[0.16em] uppercase opacity-60">
              <Star size={14} className="fill-white" /> 5.0 average from Grand Strand owners
            </div>
          </div>
          <div className="mt-12 grid md:grid-cols-3 gap-[1px] bg-white/10 border border-white/10">
            {[
              { quote: "We went from 4.7 to 4.97 after switching to Shoreline. Guests comment on how the house “smells like a luxury hotel.”", name: "Katherine M.", meta: "4BR in Garden City • Superhost 6 yrs" },
              { quote: "Photo reports are everything. I’m in Charlotte but I know exactly how my place looks before check-in. No surprises.", name: "David R.", meta: "2 condos • Surfside Beach" },
              { quote: "They found a leaking water heater during turnover and saved me $8k. That’s not cleaning, that’s property care.", name: "Jenna L.", meta: "Pawleys Island Cottage • VRBO Premier" },
            ].map((c) => (
              <div key={c.name} className="bg-white/[0.04] backdrop-blur p-8">
                <div className="flex gap-1 mb-6">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <Star key={k} size={14} className="fill-[var(--gold)] text-[var(--gold)]" />
                  ))}
                </div>
                <p className="font-display text-[18px] leading-[1.4]">“{c.quote}”</p>
                <div className="mt-8 pt-6 border-t border-white/10">
                  <div className="text-[13px] font-medium">{c.name}</div>
                  <div className="text-[11px] opacity-60 mt-1">{c.meta}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICE AREA */}
      <section id="service-area" className="mx-auto max-w-[1280px] px-6 lg:px-10 py-16 lg:py-20 scroll-mt-28">
        <div className="border border-[var(--line-strong)] bg-[var(--surface)] grid lg:grid-cols-[0.9fr_1.1fr]">
          <div className="p-8 lg:p-12">
            <div className="inline-flex items-center gap-2 text-[11px] tracking-[0.18em] uppercase px-3 py-1 bg-[var(--surface-soft)] border border-[var(--line)]">
              <MapPin size={12} /> Service Area
            </div>
            <h3 className="mt-6 text-[30px] leading-[0.95]">Proudly serving the Grand Strand’s best addresses.</h3>
            <p className="mt-4 text-[14px] leading-[1.7] opacity-70">Based in Surfside Beach, we limit our route to maintain signature quality. No overbooking.</p>
            <div className="mt-8 flex flex-wrap gap-2">
              {["Myrtle Beach", "Surfside Beach", "Garden City", "Murrells Inlet", "Pawleys Island"].map((c) => (
                <span key={c} className="px-3 py-1.5 bg-[var(--navy)] text-[var(--gold)] border border-[var(--gold)]/60 text-[11px] tracking-[0.14em] uppercase">{c}</span>
              ))}
            </div>
            <div className="mt-8 text-[12px] opacity-60 leading-[1.6]">Studios, condos, townhomes & beach homes up to 5 bedrooms • Elevator buildings OK • No large resorts</div>
          </div>
          <div className="bg-[var(--sand-2)] border-t lg:border-t-0 lg:border-l border-[var(--line-strong)] p-8 lg:p-12 grid place-items-center">
            <div className="w-full max-w-[420px] aspect-[4/3] bg-[var(--surface)] border border-[var(--line-strong)] p-4 relative">
              <div className="absolute inset-4 bg-gradient-to-br from-[#F4F6FA] to-[#E6ECF4]" />
              <svg viewBox="0 0 320 240" className="relative w-full h-full" role="img" aria-label="Map of service area along the Grand Strand">
                <path d="M20,40 Q80,20 160,60 T300,50" stroke="var(--gold)" strokeWidth="6" strokeDasharray="6 8" fill="none" opacity="0.5" />
                {[
                  { x: 40, y: 80, label: "Myrtle" },
                  { x: 90, y: 120, label: "Surfside" },
                  { x: 130, y: 155, label: "Garden City" },
                  { x: 180, y: 175, label: "Murrells" },
                  { x: 240, y: 200, label: "Pawleys" },
                ].map((c) => (
                  <g key={c.label}>
                    <circle cx={c.x} cy={c.y} r="4" fill="var(--navy)" />
                    <text x={c.x + 8} y={c.y + 4} fontSize="9" letterSpacing="0.08em" fill="var(--navy)" fontFamily="Montserrat" fontWeight="600">
                      {c.label.toUpperCase()}
                    </text>
                  </g>
                ))}
              </svg>
              <div className="absolute bottom-4 left-4 right-4 bg-[var(--navy)] text-white px-3 py-2 flex justify-between text-[10px] tracking-[0.14em] uppercase">
                <span>33.60° N, 78.93° W</span>
                <span>Grand Strand, SC</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CONTACT / BOOKING */}
      <section id="contact" className="bg-[var(--surface-soft)] border-t border-[var(--line)] scroll-mt-28">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-10 py-20 lg:py-28 grid lg:grid-cols-[1.2fr_0.8fr] gap-12 lg:gap-16 items-start">
          <div>
            <div className="text-[11px] tracking-[0.22em] uppercase text-[var(--gold-dark)] font-semibold">Book or Request a Quote</div>
            <h2 className="mt-4 text-[36px] sm:text-[48px] leading-[0.92]">Tell us about your property. We’ll craft your signature plan.</h2>
            <GoldRule />
            <p className="mt-4 text-[14px] leading-[1.7] opacity-70 max-w-[52ch]">
              Request a cleaning appointment or a custom quote for larger beach homes. We review your property, bedroom count, and preferences, then confirm your date and
              rate — usually within 2 hours.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-3 px-4 py-3 bg-[var(--surface)] border border-[var(--line-strong)]">
              <span className="text-[10px] tracking-[0.18em] uppercase opacity-60">Owners & Operators</span>
              <span className="font-script text-[22px] leading-none text-[var(--gold-dark)]">Mr. Y.Z. Tucker Jr. & Mrs. Kristin Tucker</span>
            </div>
            <BookingForm preset={preset} config={config} />
          </div>
          <div className="space-y-6">
            <div className="bg-white border border-[var(--gold)] p-6 grid place-items-center">
              <img src="/.netlify/images?url=/img/logo-full.png&w=760&fm=webp" alt="Shoreline Signature Services" width={380} height={249} className="w-full max-w-[320px] h-auto" loading="lazy" />
            </div>
            <div className="bg-[var(--navy)] text-white p-8 border-t-2 border-[var(--gold)]">
              <h3 className="text-[20px] text-[var(--gold)]">Contact & Hours</h3>
              <div className="mt-6 space-y-5 text-[13px]">
                <div className="flex gap-3">
                  <Mail size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
                  <div className="min-w-0">
                    <div className="opacity-60 text-[11px] tracking-[0.14em] uppercase">Email</div>
                    <a href={`mailto:${EMAIL}`} className="font-medium hover:text-[var(--gold)] break-all">{EMAIL}</a>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Phone size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
                  <div>
                    <div className="opacity-60 text-[11px] tracking-[0.14em] uppercase">Phone</div>
                    <a href={`tel:${PHONE_TEL}`} className="font-medium hover:text-[var(--gold)] transition">{PHONE_DISPLAY}</a>
                    <div className="opacity-60 text-[11px] mt-1">Text preferred for turnovers</div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Clock size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
                  <div>
                    <div className="opacity-60 text-[11px] tracking-[0.14em] uppercase">Hours</div>
                    <div>Mon–Sun 7am–9pm</div>
                    <div className="opacity-60 text-[11px] mt-1">Emergency line for active stays</div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AtSign size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
                  <div>
                    <div className="opacity-60 text-[11px] tracking-[0.14em] uppercase">Follow</div>
                    <div>@shorelinesignature.sc</div>
                  </div>
                </div>
              </div>
              <div className="mt-8 pt-8 border-t border-white/10">
                <div className="text-[11px] tracking-[0.16em] uppercase opacity-60">What happens next?</div>
                <ol className="mt-3 space-y-2 text-[12px] leading-[1.6] opacity-80 list-decimal pl-4">
                  <li>We review your request & confirm your date and rate</li>
                  <li>Secure your booking with a deposit through Square</li>
                  <li>Your signature turnover, complete with photo report</li>
                </ol>
              </div>
            </div>
            {config?.squareUrl && (
              <div className="border border-[var(--gold)] bg-[var(--surface)] p-6">
                <div className="flex items-center gap-2 text-[11px] tracking-[0.16em] uppercase text-[var(--gold-dark)] font-semibold">
                  <Lock size={14} /> Secure Deposits & Payments
                </div>
                <p className="mt-3 text-[13px] leading-[1.6] opacity-75">
                  {config.depositNote || "Already confirmed your booking with us? Pay your deposit or balance securely online through Square."}
                </p>
                <a
                  href={config.squareUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 h-11 w-full bg-[var(--navy)] text-white text-[12px] tracking-[0.14em] uppercase font-semibold hover:bg-[var(--navy-2)] transition flex items-center justify-center gap-2"
                >
                  Pay Deposit with Square <ArrowRight size={14} />
                </a>
              </div>
            )}
            <div className="border border-[var(--line-strong)] bg-[var(--surface)] p-6">
              <div className="flex items-center gap-2 text-[11px] tracking-[0.16em] uppercase">
                <ShieldCheck size={14} /> Licensed • Insured • Background Checked
              </div>
              <p className="mt-3 text-[12px] leading-[1.6] opacity-60">
                Fully insured with liability coverage and a strict key-handling protocol. Your property details are stored securely and shared only with your assigned team.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#070F1E] text-white/70 border-t-2 border-[var(--gold)]">
        <div className="mx-auto max-w-[1280px] px-6 lg:px-10 py-12 flex flex-col lg:flex-row justify-between gap-8">
          <div>
            <div className="flex items-start gap-3 text-white">
              <img src="/.netlify/images?url=/img/logo-emblem.png&w=128&h=128&fm=webp" alt="" aria-hidden="true" width={64} height={64} className="shrink-0 rounded-full ring-2 ring-[var(--gold)]" />
              <span className="leading-[0.95]">
                <span className="block font-display font-[700] tracking-[0.2em] text-[15px]">SHORELINE SIGNATURE SERVICES</span>
                <span className="block font-[400] tracking-[0.18em] text-[10px] opacity-70 mt-1">THE SIGNATURE OF A PERFECT STAY</span>
                <span className="block mt-3 text-[19px] font-script text-[var(--gold)]">
                  Owners & Operators: Mr. Y.Z. Tucker Jr. & Mrs. Kristin Tucker
                </span>
              </span>
            </div>
            <div className="mt-6 text-[12px] leading-[1.7] max-w-[40ch] opacity-60">
              Luxury vacation rental turnover, cleaning, concierge & property care. Serving Myrtle Beach, Surfside, Garden City, Murrells Inlet & Pawleys Island.
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-10 text-[12px]">
            <div>
              <div className="text-white text-[11px] tracking-[0.16em] uppercase mb-3">Contact</div>
              <div className="space-y-2 opacity-70">
                <div><a href={`mailto:${EMAIL}`} className="hover:text-white transition break-all">{EMAIL}</a></div>
                <div><a href={`tel:${PHONE_TEL}`} className="hover:text-white transition">{PHONE_DISPLAY}</a></div>
                <div>Surfside Beach, SC</div>
              </div>
            </div>
            <div>
              <div className="text-white text-[11px] tracking-[0.16em] uppercase mb-3">Services</div>
              <div className="space-y-2 opacity-70 flex flex-col items-start">
                <button onClick={() => go("services")} className="hover:text-white transition">Turnover Cleaning</button>
                <button onClick={() => go("properties")} className="hover:text-white transition">Rentals & Beach Homes</button>
                <button onClick={() => go("contact")} className="hover:text-white transition">Request a Quote</button>
                {config?.squareUrl && (
                  <a href={config.squareUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition">Pay a Deposit</a>
                )}
              </div>
            </div>
            <div>
              <div className="text-white text-[11px] tracking-[0.16em] uppercase mb-3">Team</div>
              <div className="space-y-2 opacity-70">
                <div><a href="/portal/" className="hover:text-white transition">Owner Login</a></div>
                <div><a href="/portal/" className="hover:text-white transition">Employee Login</a></div>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto max-w-[1280px] px-6 lg:px-10 min-h-12 py-3 flex flex-wrap gap-2 items-center justify-between text-[11px] opacity-40">
            <span>© {new Date().getFullYear()} Shoreline Signature Services LLC • All rights reserved</span>
            <span className="hidden sm:inline tracking-[0.14em] uppercase">Licensed & Insured • Grand Strand SC</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
