import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowRight, CheckCircle2, Lock } from "lucide-react";
import { ADD_ONS, BEDROOM_OPTIONS, PHONE_DISPLAY, PHONE_TEL, PROPERTY_TYPES, SERVICE_TYPES } from "../../shared/constants";
import type { PublicConfig } from "./Home";

type Props = { preset: { bedrooms: string; requestType: "booking" | "quote"; n: number } | null; config: PublicConfig | null };

const empty = {
  requestType: "booking" as "booking" | "quote",
  name: "",
  email: "",
  phone: "",
  address: "",
  propertyType: "",
  bedrooms: "",
  bathrooms: "",
  serviceType: SERVICE_TYPES[0] as string,
  addOns: [] as string[],
  preferredDate: "",
  preferredTime: "",
  instructions: "",
  specialRequests: "",
  company_website: "",
};

const inputCls =
  "mt-2 w-full h-11 px-3 border border-[var(--line-strong)] bg-transparent text-[14px] focus:outline-none focus:border-[var(--navy)] dark:focus:border-[var(--gold)]";
const labelCls = "text-[11px] tracking-[0.16em] uppercase opacity-60";

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function BookingForm({ preset, config }: Props) {
  const [f, setF] = useState(empty);
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ id: number; requestType: string; squareUrl: string; depositNote: string } | null>(null);
  const sending = useRef(false);
  const successRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!preset) return;
    setStatus((s) => (s === "success" ? "idle" : s));
    setF((prev) => ({ ...prev, bedrooms: preset.bedrooms, requestType: preset.requestType }));
  }, [preset]);

  useEffect(() => {
    if (status === "success") successRef.current?.focus();
  }, [status]);

  const tier = BEDROOM_OPTIONS.find((b) => b.value === f.bedrooms);
  const forcedQuote = !!tier?.quoteOnly;
  const isQuote = forcedQuote || f.requestType === "quote";
  const price = tier && config?.pricing?.[tier.value];

  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((p) => ({ ...p, [k]: v }));
  const toggleAddOn = (a: string) => setF((p) => ({ ...p, addOns: p.addOns.includes(a) ? p.addOns.filter((x) => x !== a) : [...p.addOns, a] }));

  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (sending.current) return;
    const form = e.currentTarget;
    const phone = form.elements.namedItem("phone") as HTMLInputElement;
    phone.setCustomValidity(f.phone.replace(/\D/g, "").length >= 7 ? "" : "Please enter a phone number with at least 7 digits.");
    for (const n of ["name", "address"]) {
      const el = form.elements.namedItem(n) as HTMLInputElement;
      el.setCustomValidity(el.value.trim() ? "" : "Please enter this information.");
    }
    if (!form.reportValidity()) return;
    sending.current = true;
    setStatus("sending");
    setError("");
    try {
      const res = await fetch("/api/public/booking-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...f, requestType: isQuote ? "quote" : "booking" }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "We couldn’t send your request. Please try again.");
      setResult(data);
      setStatus("success");
      setF(empty);
    } catch (err) {
      setError(err instanceof Error ? err.message : "We couldn’t send your request.");
      setStatus("error");
    } finally {
      sending.current = false;
    }
  }

  if (status === "success" && result) {
    return (
      <div ref={successRef} tabIndex={-1} className="mt-10 bg-[var(--surface)] border border-[var(--line-strong)] p-6 lg:p-8 focus:outline-none" role="status">
        <div className="h-12 w-12 rounded-full bg-[var(--navy)] text-[var(--gold)] grid place-items-center">
          <CheckCircle2 size={22} />
        </div>
        <h3 className="mt-6 text-[28px] leading-[1.05]">{result.requestType === "quote" ? "Your quote request is in." : "Your booking request is in."}</h3>
        <p className="mt-3 text-[14px] leading-[1.7] opacity-75 max-w-[56ch]">
          Thank you — request <span className="font-semibold">#{result.id}</span> has been received. We’ll review your property details and reach out to confirm{" "}
          {result.requestType === "quote" ? "your personalized quote" : "your date and rate"}, usually within 2 hours (7am–9pm). Your appointment is confirmed once we
          contact you.
        </p>
        {result.squareUrl && (
          <div className="mt-6 border border-[var(--gold)] p-5">
            <div className="flex items-center gap-2 text-[11px] tracking-[0.16em] uppercase text-[var(--gold-dark)] font-semibold">
              <Lock size={13} /> Secure your date
            </div>
            <p className="mt-2 text-[13px] leading-[1.6] opacity-75">
              {result.depositNote || "You can place your deposit now through our secure Square checkout. Please include your request number with your payment."}
            </p>
            <a
              href={result.squareUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 h-11 px-6 inline-flex bg-[var(--navy)] text-white text-[12px] tracking-[0.14em] uppercase font-semibold hover:bg-[var(--navy-2)] transition items-center gap-2"
            >
              Pay Deposit with Square <ArrowRight size={14} />
            </a>
          </div>
        )}
        <div className="mt-6 flex flex-wrap gap-3 text-[13px]">
          <button
            onClick={() => {
              setStatus("idle");
              setResult(null);
            }}
            className="h-11 px-6 border border-[var(--line-strong)] text-[12px] tracking-[0.14em] uppercase font-semibold hover:bg-[var(--surface-soft)]"
          >
            Submit another property
          </button>
          <a href={`tel:${PHONE_TEL}`} className="h-11 px-6 inline-flex items-center text-[12px] tracking-[0.14em] uppercase font-semibold opacity-70 hover:opacity-100">
            Call {PHONE_DISPLAY}
          </a>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate={false} className="mt-10 bg-[var(--surface)] border border-[var(--line-strong)] p-6 lg:p-8 space-y-5" aria-label="Booking and quote request">
      <div className="grid grid-cols-2 gap-[1px] bg-[var(--line-strong)] border border-[var(--line-strong)]" role="radiogroup" aria-label="Request type">
        {(["booking", "quote"] as const).map((t) => {
          const on = t === "quote" ? isQuote : !isQuote;
          const disabled = t === "booking" && forcedQuote;
          return (
            <button
              type="button"
              key={t}
              role="radio"
              aria-checked={on}
              disabled={disabled}
              onClick={() => set("requestType", t)}
              className={`h-12 text-[11px] sm:text-[12px] tracking-[0.14em] uppercase font-semibold transition ${on ? "bg-[var(--navy)] text-white" : "bg-[var(--surface)] opacity-70 hover:opacity-100"} disabled:opacity-30`}
            >
              {t === "booking" ? "Request Appointment" : "Request a Quote"}
            </button>
          );
        })}
      </div>

      <fieldset className="space-y-5">
        <legend className="text-[11px] tracking-[0.22em] uppercase font-semibold text-[var(--gold-dark)] mb-4">Your contact information</legend>
        <div className="grid sm:grid-cols-2 gap-5">
          <label className="block">
            <span className={labelCls}>Full Name *</span>
            <input name="name" autoComplete="name" value={f.name} onChange={(e) => set("name", e.target.value)} required maxLength={120} className={inputCls} />
          </label>
          <label className="block">
            <span className={labelCls}>Phone *</span>
            <input name="phone" type="tel" autoComplete="tel" value={f.phone} onChange={(e) => set("phone", e.target.value)} required maxLength={40} className={inputCls} />
          </label>
        </div>
        <label className="block">
          <span className={labelCls}>Email *</span>
          <input name="email" type="email" autoComplete="email" value={f.email} onChange={(e) => set("email", e.target.value)} required maxLength={200} className={inputCls} />
        </label>
      </fieldset>

      <fieldset className="space-y-5 pt-2">
        <legend className="text-[11px] tracking-[0.22em] uppercase font-semibold text-[var(--gold-dark)] mb-4">Property details</legend>
        <label className="block">
          <span className={labelCls}>Property Address *</span>
          <input
            name="address"
            autoComplete="street-address"
            value={f.address}
            onChange={(e) => set("address", e.target.value)}
            required
            maxLength={300}
            className={inputCls}
            placeholder="Street, city, unit #"
          />
        </label>
        <div className="grid sm:grid-cols-3 gap-5">
          <label className="block sm:col-span-1">
            <span className={labelCls}>Bedrooms *</span>
            <select name="bedrooms" value={f.bedrooms} onChange={(e) => set("bedrooms", e.target.value)} required className={inputCls + " bg-[var(--surface)]"}>
              <option value="">Select…</option>
              {BEDROOM_OPTIONS.map((b) => (
                <option key={b.value} value={b.value}>
                  {b.label}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className={labelCls}>Bathrooms</span>
            <input name="bathrooms" inputMode="decimal" value={f.bathrooms} onChange={(e) => set("bathrooms", e.target.value)} maxLength={20} className={inputCls} placeholder="e.g. 2.5" />
          </label>
          <label className="block">
            <span className={labelCls}>Property Type</span>
            <select value={f.propertyType} onChange={(e) => set("propertyType", e.target.value)} className={inputCls + " bg-[var(--surface)]"}>
              <option value="">Select…</option>
              {PROPERTY_TYPES.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </label>
        </div>
        {tier && (
          <div className={`px-4 py-3 text-[13px] leading-[1.5] border ${isQuote ? "border-[var(--gold)] bg-[var(--gold)]/10" : "border-[var(--line-strong)] bg-[var(--surface-soft)]"}`}>
            {forcedQuote
              ? `${tier.label}s are custom quoted — pricing depends on property size, condition, and cleaning requirements. We’ll send a personalized quote.`
              : isQuote
                ? "We’ll review your property and send a personalized quote."
                : price
                  ? `Standard turnovers for a ${tier.label.toLowerCase()} start at $${price}. Add-ons are quoted when we confirm your booking.`
                  : "We’ll confirm your rate when we review your request."}
          </div>
        )}
        <label className="block">
          <span className={labelCls}>Service Type</span>
          <select value={f.serviceType} onChange={(e) => set("serviceType", e.target.value)} className={inputCls + " bg-[var(--surface)]"}>
            {SERVICE_TYPES.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <div>
          <span className={labelCls}>Additional Services</span>
          <div className="mt-3 grid sm:grid-cols-2 gap-2">
            {ADD_ONS.map((a) => {
              const on = f.addOns.includes(a);
              return (
                <label
                  key={a}
                  className={`flex items-center gap-3 px-3 py-2.5 border text-[13px] cursor-pointer transition ${on ? "border-[var(--navy)] bg-[var(--surface-soft)] dark:border-[var(--gold)]" : "border-[var(--line-strong)]"}`}
                >
                  <input type="checkbox" checked={on} onChange={() => toggleAddOn(a)} className="h-4 w-4 accent-[#0a2342]" />
                  {a}
                </label>
              );
            })}
          </div>
        </div>
      </fieldset>

      <fieldset className="space-y-5 pt-2">
        <legend className="text-[11px] tracking-[0.22em] uppercase font-semibold text-[var(--gold-dark)] mb-4">Scheduling & instructions</legend>
        <div className="grid sm:grid-cols-2 gap-5">
          <label className="block">
            <span className={labelCls}>{isQuote ? "Target Start Date" : "Preferred Cleaning Date"}</span>
            <input type="date" min={todayStr()} value={f.preferredDate} onChange={(e) => set("preferredDate", e.target.value)} className={inputCls} />
          </label>
          <label className="block">
            <span className={labelCls}>Preferred Time / Check-in Window</span>
            <input value={f.preferredTime} onChange={(e) => set("preferredTime", e.target.value)} maxLength={40} className={inputCls} placeholder="e.g. 10am–3pm, guests at 4pm" />
          </label>
        </div>
        <label className="block">
          <span className={labelCls}>Cleaning & Access Instructions</span>
          <textarea
            value={f.instructions}
            onChange={(e) => set("instructions", e.target.value)}
            rows={3}
            maxLength={3000}
            className="mt-2 w-full px-3 py-3 border border-[var(--line-strong)] bg-transparent text-[14px] focus:outline-none focus:border-[var(--navy)] resize-y"
            placeholder="Parking, lockbox or entry details, owner’s closet, linen storage, pets…"
          />
        </label>
        <label className="block">
          <span className={labelCls}>Special Requests & Owner Preferences</span>
          <textarea
            value={f.specialRequests}
            onChange={(e) => set("specialRequests", e.target.value)}
            rows={3}
            maxLength={3000}
            className="mt-2 w-full px-3 py-3 border border-[var(--line-strong)] bg-transparent text-[14px] focus:outline-none focus:border-[var(--navy)] resize-y"
            placeholder="Anything that would make the difference for your guests"
          />
        </label>
        <label className="hidden" aria-hidden="true">
          Leave blank
          <input tabIndex={-1} autoComplete="off" value={f.company_website} onChange={(e) => set("company_website", e.target.value)} />
        </label>
      </fieldset>

      {status === "error" && (
        <div role="alert" className="px-4 py-3 border border-red-300 bg-red-50 text-red-800 text-[13px] dark:bg-red-950/40 dark:text-red-200 dark:border-red-800">
          {error} Your details are still here — please try again or call{" "}
          <a href={`tel:${PHONE_TEL}`} className="underline">{PHONE_DISPLAY}</a>.
        </div>
      )}

      <button
        type="submit"
        disabled={status === "sending"}
        className="w-full h-12 bg-[var(--navy)] text-white text-[12px] tracking-[0.16em] uppercase font-semibold hover:bg-[var(--navy-2)] transition flex items-center justify-center gap-2 disabled:opacity-60"
      >
        {status === "sending" ? "Sending…" : isQuote ? "Send Quote Request" : "Send Booking Request"} <ArrowRight size={14} />
      </button>
      <div className="text-[11px] opacity-50 text-center">We reply within 2 hours • 7am–9pm daily • Your details are stored securely • No spam</div>
    </form>
  );
}
