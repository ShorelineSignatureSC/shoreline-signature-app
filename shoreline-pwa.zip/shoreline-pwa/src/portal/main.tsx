import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "../styles.css";
import App from "./App";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

// Register the installable app worker only on secure production origins.
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch((error) => {
      console.warn("Shoreline app service worker unavailable:", error);
    });
  });
}
