import { useState, type FormEvent } from "react";
import { updateUser } from "@netlify/identity";
import { PHONE_DISPLAY, PHONE_TEL } from "../../shared/constants";
import type { Ctx } from "./App";
import { api, type Me } from "./api";
import { Button, Card, ErrorNote, Field, Input, SectionTitle } from "./ui";

export default function Account({ ctx, onUpdated }: { ctx: Ctx; onUpdated: (m: Me) => void }) {
  const [name, setName] = useState(ctx.me.name);
  const [phone, setPhone] = useState(ctx.me.phone);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const saveProfile = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await api<{ me: Me }>("/api/portal/me", { method: "PATCH", body: { name, phone } });
      onUpdated(r.me);
      ctx.toast("Profile saved");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save.");
    } finally {
      setBusy(false);
    }
  };
  const savePw = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    if (pw.length < 8) return setError("Password must be at least 8 characters.");
    if (pw !== pw2) return setError("Passwords don’t match.");
    setBusy(true);
    try {
      await updateUser({ password: pw });
      setPw("");
      setPw2("");
      ctx.toast("Password changed");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not change password.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-[640px]">
      <SectionTitle eyebrow={ctx.me.role === "owner" ? "Owner / Admin" : "Employee"} title="My account" />
      <div className="space-y-6">
        <ErrorNote>{error}</ErrorNote>
        <Card className="p-5 sm:p-6">
          <form onSubmit={saveProfile} className="space-y-4">
            <h2 className="text-[18px]">Profile</h2>
            <div className="text-[13px] opacity-60">{ctx.me.email}</div>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Name">
                <Input value={name} onChange={(e) => setName(e.target.value)} required />
              </Field>
              <Field label="Phone">
                <Input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </Field>
            </div>
            <div className="flex justify-end">
              <Button type="submit" disabled={busy}>Save profile</Button>
            </div>
          </form>
        </Card>
        <Card className="p-5 sm:p-6">
          <form onSubmit={savePw} className="space-y-4">
            <h2 className="text-[18px]">Change password</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="New password">
                <Input type="password" autoComplete="new-password" value={pw} onChange={(e) => setPw(e.target.value)} />
              </Field>
              <Field label="Confirm">
                <Input type="password" autoComplete="new-password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
              </Field>
            </div>
            <div className="flex justify-end">
              <Button type="submit" disabled={busy}>Update password</Button>
            </div>
          </form>
        </Card>
        <p className="text-[12px] opacity-60">
          Questions about a job? Contact the office at <a href={`tel:${PHONE_TEL}`} className="underline">{PHONE_DISPLAY}</a>.
        </p>
      </div>
    </div>
  );
}
