import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { BookOpen, CheckCircle2, Download, ExternalLink, FileText, Film, Link2, Pencil, Plus, Search, Trash2, Upload } from "lucide-react";
import { TRAINING_CATEGORIES } from "../../shared/constants";
import type { Ctx } from "./App";
import { api, type Material } from "./api";
import { fmtDateTime } from "./dates";
import { Button, Card, Empty, ErrorNote, Field, Input, Modal, SectionTitle, Select, Spinner, Tag, Textarea } from "./ui";

const fileUrl = (m: Material, download = false) => `/api/files/training/${m.id}${download ? "?download=1" : ""}`;
const isVideo = (m: Material) => m.kind === "file" && m.contentType.startsWith("video/");
const isImage = (m: Material) => m.kind === "file" && m.contentType.startsWith("image/");
const isPdf = (m: Material) => m.kind === "file" && m.contentType === "application/pdf";
const fmtSize = (n: number) => (n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function embedUrl(url: string) {
  try {
    const u = new URL(url);
    if (/youtube\.com$/.test(u.hostname.replace(/^www\.|^m\./, "")) && u.searchParams.get("v")) return `https://www.youtube-nocookie.com/embed/${u.searchParams.get("v")}`;
    if (u.hostname === "youtu.be") return `https://www.youtube-nocookie.com/embed/${u.pathname.slice(1)}`;
    if (/(^|\.)vimeo\.com$/.test(u.hostname) && /^\/\d+/.test(u.pathname)) return `https://player.vimeo.com/video/${u.pathname.split("/")[1]}`;
  } catch {
    /* not embeddable */
  }
  return null;
}

function KindIcon({ m }: { m: Material }) {
  const I = isVideo(m) || (m.kind === "link" && embedUrl(m.externalUrl)) ? Film : m.kind === "link" ? Link2 : FileText;
  return <I size={16} className="text-[var(--gold)]" />;
}

export default function Training({ ctx }: { ctx: Ctx }) {
  const owner = ctx.me.role === "owner";
  const [items, setItems] = useState<Material[] | null>(null);
  const [activeEmployees, setActiveEmployees] = useState(0);
  const [error, setError] = useState("");
  const [cat, setCat] = useState("");
  const [q, setQ] = useState("");
  const [viewing, setViewing] = useState<Material | null>(null);
  const [editing, setEditing] = useState<Material | "new" | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<{ materials: Material[]; activeEmployees: number }>("/api/portal/training");
      setItems(r.materials);
      setActiveEmployees(r.activeEmployees);
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load training materials.");
    }
  }, []);
  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return (items ?? []).filter(
      (m) => (!cat || m.category === cat) && (!s || m.title.toLowerCase().includes(s) || m.description.toLowerCase().includes(s) || m.body.toLowerCase().includes(s)),
    );
  }, [items, cat, q]);
  const grouped = useMemo(() => {
    const g = new Map<string, Material[]>();
    for (const c of TRAINING_CATEGORIES) g.set(c, []);
    for (const m of filtered) g.set(m.category, [...(g.get(m.category) ?? []), m]);
    return [...g.entries()].filter(([, v]) => v.length);
  }, [filtered]);

  const requiredLeft = (items ?? []).filter((m) => m.required && !m.completedByMe).length;

  const toggleDone = async (m: Material) => {
    try {
      await api(`/api/portal/training/${m.id}/complete`, { method: "POST", body: { done: !m.completedByMe } });
      setItems((prev) => prev?.map((x) => (x.id === m.id ? { ...x, completedByMe: !m.completedByMe } : x)) ?? null);
      setViewing((v) => (v && v.id === m.id ? { ...v, completedByMe: !m.completedByMe } : v));
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Could not update");
    }
  };
  const remove = async (m: Material) => {
    if (!confirm(`Delete “${m.title}”? Employees will no longer be able to access it.`)) return;
    try {
      await api(`/api/portal/training/${m.id}`, { method: "DELETE" });
      ctx.toast("Material deleted");
      setViewing(null);
      load();
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Could not delete");
    }
  };

  return (
    <div>
      <SectionTitle
        eyebrow="Training & employee resources"
        title="Training Center"
        action={
          owner ? (
            <Button onClick={() => setEditing("new")}>
              <Plus size={14} /> Add material
            </Button>
          ) : undefined
        }
      />
      {!owner && requiredLeft > 0 && (
        <div className="mb-5 px-4 py-3 bg-[var(--gold)]/15 border border-[var(--gold)]/50 text-[13px]">
          You have <strong>{requiredLeft}</strong> required item{requiredLeft > 1 ? "s" : ""} to review. Open each one and tap “Mark as reviewed” when finished.
        </div>
      )}
      <Card className="p-3 sm:p-4 flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-40" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search training, checklists, policies…" className="pl-9 h-10" aria-label="Search training" />
        </div>
        <Select value={cat} onChange={(e) => setCat(e.target.value)} className="h-10 sm:w-[280px]" aria-label="Category">
          <option value="">All categories</option>
          {TRAINING_CATEGORIES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </Select>
      </Card>
      <ErrorNote>{error}</ErrorNote>
      {items === null ? (
        <Spinner />
      ) : items.length === 0 ? (
        <Empty title="No training materials yet">
          {owner
            ? "Upload training videos, step-by-step instructions, checklists, turnover and linen procedures, staging guides, inspection standards and company policies."
            : "The owner hasn’t published training materials yet. Check back soon."}
        </Empty>
      ) : grouped.length === 0 ? (
        <Empty title="Nothing matches your search" />
      ) : (
        <div className="space-y-8">
          {grouped.map(([category, list]) => (
            <section key={category}>
              <h2 className="text-[18px] mb-3">{category}</h2>
              <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {list.map((m) => (
                  <button key={m.id} onClick={() => setViewing(m)} className="text-left bg-[var(--surface)] border border-[var(--line-strong)] p-4 hover:border-[var(--navy)] dark:hover:border-[var(--gold)] transition flex flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <KindIcon m={m} />
                      <div className="flex gap-1">
                        {m.required && <Tag tone="gold">Required</Tag>}
                        {!owner && m.completedByMe && <Tag tone="navy">Reviewed</Tag>}
                      </div>
                    </div>
                    <div className="mt-3 font-medium text-[15px] leading-[1.3]">{m.title}</div>
                    {m.description && <div className="mt-1 text-[12px] opacity-65 line-clamp-2">{m.description}</div>}
                    <div className="mt-auto pt-3 text-[11px] opacity-50">
                      {m.kind === "file" ? `${m.fileName} · ${fmtSize(m.fileSize)}` : m.kind === "link" ? "External link" : "Written guide"}
                      {owner && ` · ${m.completions ?? 0}/${activeEmployees} reviewed`}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {viewing && (
        <Modal title={viewing.title} onClose={() => setViewing(null)} wide>
          <div className="space-y-5">
            <div className="flex flex-wrap gap-2 items-center">
              <Tag>{viewing.category}</Tag>
              {viewing.required && <Tag tone="gold">Required</Tag>}
              <span className="text-[11px] opacity-50">Updated {fmtDateTime(viewing.updatedAt)}</span>
            </div>
            {viewing.description && <p className="text-[14px] opacity-80 leading-[1.6]">{viewing.description}</p>}
            {isVideo(viewing) && (
              <video controls playsInline preload="metadata" className="w-full max-h-[60vh] bg-black" src={fileUrl(viewing)}>
                Your browser can’t play this video. <a href={fileUrl(viewing, true)}>Download it</a>.
              </video>
            )}
            {isImage(viewing) && <img src={fileUrl(viewing)} alt={viewing.title} className="w-full max-h-[70vh] object-contain bg-[var(--surface-soft)]" />}
            {isPdf(viewing) && <iframe title={viewing.title} src={fileUrl(viewing)} className="w-full h-[65vh] border border-[var(--line-strong)] bg-white" />}
            {viewing.kind === "link" && embedUrl(viewing.externalUrl) && (
              <div className="aspect-video">
                <iframe title={viewing.title} src={embedUrl(viewing.externalUrl)!} className="w-full h-full" allow="fullscreen; picture-in-picture" allowFullScreen />
              </div>
            )}
            {viewing.body && <div className="text-[14px] leading-[1.75] whitespace-pre-wrap bg-[var(--surface)] border border-[var(--line)] p-4 sm:p-5">{viewing.body}</div>}
            <div className="flex flex-wrap gap-3 pt-2 border-t border-[var(--line)]">
              {viewing.kind === "file" && (
                <a href={fileUrl(viewing, true)} className="h-11 px-5 text-[12px] border border-[var(--line-strong)] hover:bg-[var(--surface-soft)] tracking-[0.12em] uppercase font-semibold inline-flex items-center gap-2">
                  <Download size={14} /> Download
                </a>
              )}
              {viewing.kind === "file" && !isVideo(viewing) && !isImage(viewing) && (
                <a href={fileUrl(viewing)} target="_blank" rel="noopener" className="h-11 px-5 text-[12px] border border-[var(--line-strong)] hover:bg-[var(--surface-soft)] tracking-[0.12em] uppercase font-semibold inline-flex items-center gap-2">
                  <ExternalLink size={14} /> Open
                </a>
              )}
              {viewing.externalUrl && (
                <a href={viewing.externalUrl} target="_blank" rel="noopener noreferrer" className="h-11 px-5 text-[12px] border border-[var(--line-strong)] hover:bg-[var(--surface-soft)] tracking-[0.12em] uppercase font-semibold inline-flex items-center gap-2">
                  <ExternalLink size={14} /> Open link
                </a>
              )}
              {!owner && (
                <Button variant={viewing.completedByMe ? "outline" : "primary"} onClick={() => toggleDone(viewing)}>
                  <CheckCircle2 size={14} /> {viewing.completedByMe ? "Reviewed ✓ (undo)" : "Mark as reviewed"}
                </Button>
              )}
              {owner && (
                <>
                  <Button variant="outline" onClick={() => (setEditing(viewing), setViewing(null))}>
                    <Pencil size={14} /> Edit
                  </Button>
                  <Button variant="danger" onClick={() => remove(viewing)}>
                    <Trash2 size={14} /> Delete
                  </Button>
                </>
              )}
            </div>
          </div>
        </Modal>
      )}
      {editing && owner && (
        <MaterialEditor
          material={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            ctx.toast("Training material saved");
            load();
          }}
        />
      )}
    </div>
  );
}

function MaterialEditor({ material, onClose, onSaved }: { material: Material | null; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    title: material?.title ?? "",
    category: material?.category ?? TRAINING_CATEGORIES[0],
    description: material?.description ?? "",
    body: material?.body ?? "",
    externalUrl: material?.externalUrl ?? "",
    required: material?.required ?? false,
  });
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    if (!f.title.trim()) return setError("Please add a title.");
    if (!material && !file && !f.body.trim() && !f.externalUrl.trim()) return setError("Add a file, a video link, or written instructions.");
    setBusy(true);
    try {
      if (material) {
        await api(`/api/portal/training/${material.id}`, { method: "PATCH", body: f });
      } else {
        let fileMeta: Record<string, unknown> = {};
        if (file) {
          const init = await api<{ fileId: string; chunkSize: number; chunkCount: number }>("/api/files/training/init", { method: "POST", body: { size: file.size } });
          setProgress(0);
          for (let i = 0; i < init.chunkCount; i++) {
            const part = file.slice(i * init.chunkSize, Math.min(file.size, (i + 1) * init.chunkSize));
            let attempt = 0;
            for (;;) {
              try {
                await api(`/api/files/training/upload/${init.fileId}/${i}`, { method: "PUT", raw: part, contentType: "application/octet-stream" });
                break;
              } catch (err) {
                if (++attempt >= 3) throw err;
                await new Promise((r) => setTimeout(r, 1000 * attempt));
              }
            }
            setProgress(Math.round(((i + 1) / init.chunkCount) * 100));
          }
          fileMeta = { fileId: init.fileId, fileName: file.name, contentType: file.type || "application/octet-stream", fileSize: file.size };
        }
        await api("/api/portal/training", { method: "POST", body: { ...f, ...fileMeta } });
      }
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save.");
      setBusy(false);
      setProgress(null);
    }
  };

  return (
    <Modal title={material ? "Edit training material" : "Add training material"} onClose={() => !busy && onClose()} wide>
      <form onSubmit={submit} className="space-y-4">
        <ErrorNote>{error}</ErrorNote>
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Title *">
            <Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} required placeholder="e.g. Signature Turnover — Kitchen" />
          </Field>
          <Field label="Category">
            <Select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
              {TRAINING_CATEGORIES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Short description">
          <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        </Field>
        {!material && (
          <Field label="Upload a file" hint="Videos (MP4/MOV), PDFs, images or documents — up to 1 GB. Large videos upload in parts; keep this window open.">
            <label className="flex items-center gap-3 border border-dashed border-[var(--line-strong)] p-4 cursor-pointer hover:bg-[var(--surface-soft)]">
              <Upload size={18} className="text-[var(--gold)]" />
              <span className="text-[13px] flex-1 truncate">{file ? `${file.name} · ${fmtSize(file.size)}` : "Choose a file…"}</span>
              <input type="file" className="hidden" accept="video/*,image/*,application/pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
            </label>
          </Field>
        )}
        {material?.kind === "file" && <p className="text-[12px] opacity-60">Attached file: {material.fileName}. To replace it, delete this item and upload a new one.</p>}
        <Field label="Video or document link (optional)" hint="YouTube and Vimeo links play right inside the portal">
          <Input type="url" value={f.externalUrl} onChange={(e) => setF({ ...f, externalUrl: e.target.value })} placeholder="https://" />
        </Field>
        <Field label="Written instructions / checklist (optional)">
          <Textarea rows={8} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} placeholder={"Step 1 — …\nStep 2 — …"} />
        </Field>
        <label className="flex items-center gap-3 text-[13px]">
          <input type="checkbox" checked={f.required} onChange={(e) => setF({ ...f, required: e.target.checked })} className="h-4 w-4 accent-[#0a2342]" />
          Required for all employees (tracks who has reviewed it)
        </label>
        {progress !== null && (
          <div>
            <div className="h-2 bg-[var(--surface-soft)] overflow-hidden">
              <div className="h-full bg-[var(--gold)] transition-all" style={{ width: `${progress}%` }} />
            </div>
            <div className="text-[11px] opacity-60 mt-1">Uploading… {progress}%</div>
          </div>
        )}
        <div className="flex gap-3 justify-end pt-2">
          <Button type="button" variant="outline" onClick={onClose} disabled={busy}>Cancel</Button>
          <Button type="submit" disabled={busy}>
            <BookOpen size={14} /> {busy ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
