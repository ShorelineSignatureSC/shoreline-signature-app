import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, Camera, CheckCircle2, Clock, Edit3, ImagePlus, MapPin, Navigation, Phone, Mail, Play, Trash2, X } from "lucide-react";
import { BOOKING_STATUSES, DEPOSIT_STATUSES, REPORT_CHECKLIST, bedroomLabel } from "../../shared/constants";
import type { Ctx } from "./App";
import { api, ApiError, type BookingDetail, type Photo } from "./api";
import { fmtDate, fmtDateTime, fmtTime, relativeDay } from "./dates";
import { Button, Card, ErrorNote, Field, Modal, Spinner, StatusBadge, Tag, Textarea } from "./ui";
import BookingEditor from "./owner/BookingEditor";

async function compressImage(file: File): Promise<Blob> {
  if (!file.type.startsWith("image/")) throw new Error("Please choose a photo.");
  try {
    const bmp = await createImageBitmap(file);
    const max = 1800;
    const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d")!.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise<Blob | null>((r) => canvas.toBlob(r, "image/jpeg", 0.82));
    if (blob) return blob;
  } catch {
    /* fall back to the original file (e.g. HEIC on browsers that can't decode it) */
  }
  if (file.size > 5 * 1024 * 1024) throw new Error("This photo is too large. Please use a smaller image.");
  return file;
}

function PhotoGrid({ photos, onOpen, onDelete, canDelete }: { photos: Photo[]; onOpen: (p: Photo) => void; onDelete: (p: Photo) => void; canDelete: (p: Photo) => boolean }) {
  if (!photos.length) return <p className="text-[12px] opacity-50 py-3">No photos yet.</p>;
  return (
    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
      {photos.map((p) => (
        <div key={p.id} className="relative group aspect-square bg-[var(--surface-soft)] overflow-hidden">
          <button onClick={() => onOpen(p)} className="w-full h-full" aria-label={`Open ${p.kind} photo`}>
            <img src={`/api/files/photos/${p.id}`} alt={`${p.kind} photo`} className="w-full h-full object-cover" loading="lazy" />
          </button>
          {canDelete(p) && (
            <button
              onClick={() => onDelete(p)}
              className="absolute top-1 right-1 h-7 w-7 grid place-items-center bg-black/60 text-white opacity-100 sm:opacity-0 group-hover:opacity-100 transition"
              aria-label="Delete photo"
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

export default function BookingPage({ ctx, id }: { ctx: Ctx; id: number }) {
  const owner = ctx.me.role === "owner";
  const [d, setD] = useState<BookingDetail | null>(null);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState<"before" | "after" | null>(null);
  const [viewer, setViewer] = useState<Photo | null>(null);
  const beforeInput = useRef<HTMLInputElement>(null);
  const afterInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      setD(await api<BookingDetail>(`/api/portal/bookings/${id}`));
      setError("");
    } catch (e) {
      setError(e instanceof ApiError && e.status === 404 ? "This booking doesn’t exist or isn’t assigned to you." : e instanceof Error ? e.message : "Could not load booking.");
    }
  }, [id]);

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [load]);

  const back = () => ctx.navigate(owner ? "/bookings" : "/");

  if (error && !d)
    return (
      <div>
        <button onClick={back} className="text-[12px] tracking-[0.12em] uppercase opacity-70 flex items-center gap-1.5 mb-6">
          <ArrowLeft size={14} /> Back
        </button>
        <ErrorNote>{error}</ErrorNote>
      </div>
    );
  if (!d) return <Spinner />;

  const b = d.booking;
  const act = async (path: string, msg: string) => {
    setBusy(true);
    try {
      setD(await api<BookingDetail>(`/api/portal/bookings/${id}/${path}`, { method: "POST", body: {} }));
      ctx.toast(msg);
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setBusy(false);
    }
  };
  const setStatus = async (status: string) => {
    setBusy(true);
    try {
      setD(await api<BookingDetail>(`/api/portal/bookings/${id}`, { method: "PATCH", body: { status } }));
      ctx.toast("Status updated");
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Could not update");
    } finally {
      setBusy(false);
    }
  };
  const remove = async () => {
    if (!confirm(`Permanently delete booking #${b.id} for ${b.customerName}? This also removes its photos and reports.`)) return;
    try {
      await api(`/api/portal/bookings/${id}`, { method: "DELETE" });
      ctx.toast("Booking deleted");
      back();
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Could not delete");
    }
  };
  const upload = async (kind: "before" | "after", files: FileList | null) => {
    if (!files?.length) return;
    setUploading(kind);
    let ok = 0;
    let failMsg = "";
    for (const file of Array.from(files)) {
      try {
        const blob = await compressImage(file);
        await api(`/api/files/photos/booking/${id}?kind=${kind}`, { method: "POST", raw: blob, contentType: blob.type || file.type });
        ok++;
      } catch (e) {
        failMsg = e instanceof Error ? e.message : "Upload failed";
      }
    }
    setUploading(null);
    if (ok) ctx.toast(`${ok} ${kind} photo${ok > 1 ? "s" : ""} uploaded`);
    if (failMsg) ctx.toast(failMsg);
    load();
  };
  const deletePhoto = async (p: Photo) => {
    if (!confirm("Delete this photo?")) return;
    try {
      await api(`/api/files/photos/${p.id}`, { method: "DELETE" });
      load();
    } catch (e) {
      ctx.toast(e instanceof Error ? e.message : "Could not delete photo");
    }
  };

  const before = d.photos.filter((p) => p.kind === "before");
  const after = d.photos.filter((p) => p.kind === "after");
  const mapUrl = b.propertyAddress ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(b.propertyAddress)}` : "";
  const closed = b.status === "completed" || b.status === "cancelled";
  const rel = relativeDay(b.scheduledDate);

  return (
    <div>
      <button onClick={back} className="text-[12px] tracking-[0.12em] uppercase opacity-70 hover:opacity-100 flex items-center gap-1.5 mb-5">
        <ArrowLeft size={14} /> {owner ? "All bookings" : "My jobs"}
      </button>

      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] tracking-[0.16em] uppercase opacity-50">#{b.id}</span>
            <StatusBadge status={b.status} />
            {b.requestType === "quote" && <Tag tone="gold">Quote request</Tag>}
            {owner && b.depositStatus && b.depositStatus !== "none" && <Tag tone={b.depositStatus === "paid" ? "navy" : "plain"}>{DEPOSIT_STATUSES.find((x) => x.value === b.depositStatus)?.label}</Tag>}
          </div>
          <h1 className="mt-2 text-[28px] sm:text-[36px] leading-[1]">{b.customerName}</h1>
          <div className="mt-2 text-[14px] opacity-75 flex items-center gap-2">
            <Clock size={14} />
            {b.scheduledDate ? (
              <span>
                {rel && <strong className="text-[var(--gold-dark)] dark:text-[var(--gold)] mr-1">{rel} ·</strong>}
                {fmtDate(b.scheduledDate, { weekday: "long", month: "long", day: "numeric" })}
                {b.scheduledTime ? ` at ${fmtTime(b.scheduledTime)}` : " · time TBD"}
              </span>
            ) : (
              <span>Not scheduled yet{b.preferredDate ? ` · customer requested ${fmtDate(b.preferredDate)}${b.preferredTime ? `, ${b.preferredTime}` : ""}` : ""}</span>
            )}
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {!closed && b.status !== "in_progress" && (b.scheduledDate || owner) && (
            <Button variant="gold" disabled={busy} onClick={() => act("start", "Job started")}>
              <Play size={14} /> Start job
            </Button>
          )}
          {!closed && (
            <Button disabled={busy} onClick={() => setCompleting(true)}>
              <CheckCircle2 size={14} /> Complete & report
            </Button>
          )}
          {owner && (
            <Button variant="outline" onClick={() => setEditing(true)}>
              <Edit3 size={14} /> Edit
            </Button>
          )}
        </div>
      </div>

      {owner && (
        <Card className="p-3 mb-6 flex flex-wrap items-center gap-2">
          <span className="text-[10px] tracking-[0.16em] uppercase opacity-60 mr-2">Set status</span>
          {BOOKING_STATUSES.map((s) => (
            <button
              key={s.value}
              disabled={busy || b.status === s.value}
              onClick={() => setStatus(s.value)}
              className={`h-8 px-3 text-[11px] tracking-[0.1em] uppercase font-semibold border ${b.status === s.value ? "bg-[var(--navy)] text-white border-[var(--navy)] dark:bg-[var(--gold)] dark:text-[#0a2342]" : "border-[var(--line-strong)] hover:bg-[var(--surface-soft)]"}`}
            >
              {s.label}
            </button>
          ))}
        </Card>
      )}

      <div className="grid lg:grid-cols-[1.3fr_1fr] gap-6 items-start">
        <div className="space-y-6">
          <Card className="p-5 sm:p-6">
            <h2 className="text-[18px] mb-4">Property</h2>
            <div className="flex items-start gap-3">
              <MapPin size={16} className="mt-0.5 text-[var(--gold)] shrink-0" />
              <div className="flex-1">
                <div className="text-[15px] font-medium">{b.propertyAddress || "No address on file"}</div>
                {mapUrl && (
                  <a href={mapUrl} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1.5 text-[12px] tracking-[0.1em] uppercase font-semibold text-[var(--gold-dark)] dark:text-[var(--gold)]">
                    <Navigation size={12} /> Directions
                  </a>
                )}
              </div>
            </div>
            <dl className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-[13px]">
              <div>
                <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Bedrooms</dt>
                <dd className="mt-1 font-medium">{bedroomLabel(b.bedrooms)}</dd>
              </div>
              <div>
                <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Baths</dt>
                <dd className="mt-1 font-medium">{b.bathrooms || "—"}</dd>
              </div>
              <div>
                <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Type</dt>
                <dd className="mt-1 font-medium">{b.propertyType || "—"}</dd>
              </div>
              <div>
                <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Service</dt>
                <dd className="mt-1 font-medium">{b.serviceType || "—"}</dd>
              </div>
            </dl>
            {b.addOns.length > 0 && (
              <div className="mt-5">
                <div className="text-[10px] tracking-[0.14em] uppercase opacity-50 mb-2">Additional services</div>
                <div className="flex flex-wrap gap-1.5">
                  {b.addOns.map((a) => (
                    <Tag key={a} tone="gold">{a}</Tag>
                  ))}
                </div>
              </div>
            )}
          </Card>

          <Card className="p-5 sm:p-6">
            <h2 className="text-[18px] mb-4">Cleaning instructions</h2>
            <div className="space-y-4 text-[14px] leading-[1.65]">
              <div>
                <div className="text-[10px] tracking-[0.14em] uppercase opacity-50 mb-1">Instructions & access</div>
                <p className="whitespace-pre-wrap">{b.instructions || <span className="opacity-50">None provided.</span>}</p>
              </div>
              <div>
                <div className="text-[10px] tracking-[0.14em] uppercase opacity-50 mb-1">Special requests</div>
                <p className="whitespace-pre-wrap">{b.specialRequests || <span className="opacity-50">None.</span>}</p>
              </div>
              {owner && b.internalNotes && (
                <div className="bg-[var(--surface-soft)] p-3 border-l-2 border-[var(--gold)]">
                  <div className="text-[10px] tracking-[0.14em] uppercase opacity-50 mb-1">Owner notes (private)</div>
                  <p className="whitespace-pre-wrap">{b.internalNotes}</p>
                </div>
              )}
            </div>
          </Card>

          <Card className="p-5 sm:p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[18px]">Before & after photos</h2>
              <span className="text-[11px] opacity-50">{d.photos.length} total</span>
            </div>
            {(["before", "after"] as const).map((kind) => (
              <div key={kind} className="mb-5 last:mb-0">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] tracking-[0.16em] uppercase font-semibold">{kind}</div>
                  {b.status !== "cancelled" && (
                    <>
                      <input
                        ref={kind === "before" ? beforeInput : afterInput}
                        type="file"
                        accept="image/*"
                        multiple
                        className="hidden"
                        onChange={(e) => {
                          upload(kind, e.target.files);
                          e.target.value = "";
                        }}
                      />
                      <Button size="sm" variant="outline" disabled={!!uploading} onClick={() => (kind === "before" ? beforeInput : afterInput).current?.click()}>
                        {uploading === kind ? "Uploading…" : (
                          <>
                            <ImagePlus size={13} /> Add {kind}
                          </>
                        )}
                      </Button>
                    </>
                  )}
                </div>
                <PhotoGrid photos={kind === "before" ? before : after} onOpen={setViewer} onDelete={deletePhoto} canDelete={(p) => owner || p.staffId === ctx.me.id} />
              </div>
            ))}
            <p className="mt-3 text-[11px] opacity-50 flex items-center gap-1.5">
              <Camera size={12} /> On your phone, “Add” opens the camera or photo library.
            </p>
          </Card>
        </div>

        <div className="space-y-6">
          {owner && (
            <Card className="p-5 sm:p-6">
              <h2 className="text-[18px] mb-4">Customer</h2>
              <div className="space-y-2 text-[14px]">
                {b.customerPhone && (
                  <a href={`tel:${b.customerPhone}`} className="flex items-center gap-2 hover:underline">
                    <Phone size={14} className="text-[var(--gold)]" /> {b.customerPhone}
                  </a>
                )}
                {b.customerEmail && (
                  <a href={`mailto:${b.customerEmail}`} className="flex items-center gap-2 hover:underline break-all">
                    <Mail size={14} className="text-[var(--gold)]" /> {b.customerEmail}
                  </a>
                )}
                {!b.customerPhone && !b.customerEmail && <p className="opacity-50">No contact details.</p>}
              </div>
              <dl className="mt-4 pt-4 border-t border-[var(--line)] grid grid-cols-2 gap-3 text-[13px]">
                <div>
                  <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Price / quote</dt>
                  <dd className="mt-1 font-medium">{b.price || "—"}</dd>
                </div>
                <div>
                  <dt className="text-[10px] tracking-[0.14em] uppercase opacity-50">Source</dt>
                  <dd className="mt-1 font-medium capitalize">{b.source === "website" ? "Website request" : "Added in portal"}</dd>
                </div>
              </dl>
            </Card>
          )}

          <Card className="p-5 sm:p-6">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-[18px]">Assigned team</h2>
              {owner && (
                <button onClick={() => setEditing(true)} className="text-[11px] tracking-[0.12em] uppercase font-semibold text-[var(--gold-dark)] dark:text-[var(--gold)]">
                  Change
                </button>
              )}
            </div>
            {d.assigned.length ? (
              <ul className="space-y-2">
                {d.assigned.map((a) => (
                  <li key={a.id} className="flex items-center gap-2 text-[14px]">
                    <span className="h-7 w-7 rounded-full bg-[var(--navy)] text-white grid place-items-center text-[11px]">{(a.name || "?").slice(0, 1).toUpperCase()}</span>
                    {a.name}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-[13px] opacity-60">No one assigned yet.</p>
            )}
            {(b.startedAt || b.completedAt) && (
              <div className="mt-4 pt-4 border-t border-[var(--line)] text-[12px] space-y-1 opacity-75">
                {b.startedAt && <div>Started {fmtDateTime(b.startedAt)}</div>}
                {b.completedAt && <div>Completed {fmtDateTime(b.completedAt)}</div>}
              </div>
            )}
          </Card>

          <Card className="p-5 sm:p-6">
            <h2 className="text-[18px] mb-3">Completion reports</h2>
            {d.reports.length === 0 ? (
              <p className="text-[13px] opacity-60">No report submitted yet.</p>
            ) : (
              <div className="space-y-4">
                {d.reports.map((r) => (
                  <div key={r.id} className="border border-[var(--line)] p-4">
                    <div className="flex items-center justify-between gap-2 text-[12px]">
                      <span className="font-semibold">{r.staffName || "Team member"}</span>
                      <span className="opacity-60">{fmtDateTime(r.createdAt)}</span>
                    </div>
                    <div className="mt-2 text-[12px] opacity-70">
                      Checklist: {r.checklist.length}/{REPORT_CHECKLIST.length} confirmed
                    </div>
                    {REPORT_CHECKLIST.filter((c) => !r.checklist.includes(c)).length > 0 && (
                      <div className="mt-1 text-[12px] text-[var(--gold-dark)]">
                        Not confirmed: {REPORT_CHECKLIST.filter((c) => !r.checklist.includes(c)).join("; ")}
                      </div>
                    )}
                    {r.notes && <p className="mt-2 text-[13px] whitespace-pre-wrap">{r.notes}</p>}
                    {r.issues && (
                      <p className="mt-2 text-[13px] whitespace-pre-wrap">
                        <strong>Issues / damage:</strong> {r.issues}
                      </p>
                    )}
                    {r.suppliesNeeded && (
                      <p className="mt-2 text-[13px] whitespace-pre-wrap">
                        <strong>Supplies needed:</strong> {r.suppliesNeeded}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>

          {owner && (
            <Card className="p-5 sm:p-6">
              <h2 className="text-[18px] mb-3">Activity</h2>
              <ol className="space-y-3">
                {d.events.map((e) => (
                  <li key={e.id} className="text-[13px] flex gap-3">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[var(--gold)] shrink-0" />
                    <div>
                      <div>{e.action}</div>
                      <div className="text-[11px] opacity-50">
                        {e.actor} · {fmtDateTime(e.createdAt)}
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
              <div className="mt-6 pt-4 border-t border-[var(--line)]">
                <Button variant="danger" size="sm" onClick={remove}>
                  <Trash2 size={13} /> Delete booking
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      {editing && owner && (
        <BookingEditor
          booking={b}
          assigned={d.assigned}
          onClose={() => setEditing(false)}
          onSaved={(nd) => {
            setD(nd);
            setEditing(false);
            ctx.toast("Booking saved");
          }}
        />
      )}
      {completing && (
        <CompleteModal
          id={id}
          afterCount={after.length}
          onClose={() => setCompleting(false)}
          onDone={(nd) => {
            setD(nd);
            setCompleting(false);
            ctx.toast("Job completed — report sent to the owner");
          }}
        />
      )}
      {viewer && (
        <div className="fixed inset-0 z-[95] bg-black/90 flex items-center justify-center p-4" onClick={() => setViewer(null)}>
          <button className="absolute top-4 right-4 h-10 w-10 grid place-items-center text-white" aria-label="Close photo">
            <X size={22} />
          </button>
          <img src={`/api/files/photos/${viewer.id}`} alt={`${viewer.kind} photo`} className="max-w-full max-h-full object-contain" />
          <div className="absolute bottom-4 left-0 right-0 text-center text-white/80 text-[12px]">
            {viewer.kind.toUpperCase()} · {viewer.staffName || "Team"} · {fmtDateTime(viewer.createdAt)}
          </div>
        </div>
      )}
    </div>
  );
}

function CompleteModal({ id, afterCount, onClose, onDone }: { id: number; afterCount: number; onClose: () => void; onDone: (d: BookingDetail) => void }) {
  const [checked, setChecked] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [issues, setIssues] = useState("");
  const [supplies, setSupplies] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const submit = async () => {
    setBusy(true);
    setError("");
    try {
      onDone(await api<BookingDetail>(`/api/portal/bookings/${id}/complete`, { method: "POST", body: { checklist: checked, notes, issues, suppliesNeeded: supplies } }));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not submit report.");
      setBusy(false);
    }
  };
  return (
    <Modal title="Completion report" onClose={onClose}>
      <div className="space-y-5">
        <ErrorNote>{error}</ErrorNote>
        {afterCount === 0 && (
          <div className="px-4 py-3 bg-[var(--gold)]/15 border border-[var(--gold)]/50 text-[13px]">Tip: add your “after” photos on the job page before completing so the owner can review them.</div>
        )}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] tracking-[0.16em] uppercase opacity-60 font-medium">Turnover checklist</span>
            <button type="button" className="text-[11px] underline opacity-70" onClick={() => setChecked(checked.length === REPORT_CHECKLIST.length ? [] : [...REPORT_CHECKLIST])}>
              {checked.length === REPORT_CHECKLIST.length ? "Clear all" : "Check all"}
            </button>
          </div>
          <div className="space-y-1.5">
            {REPORT_CHECKLIST.map((c) => (
              <label key={c} className={`flex items-center gap-3 px-3 py-2.5 border text-[13px] ${checked.includes(c) ? "border-[var(--navy)] bg-[var(--surface-soft)] dark:border-[var(--gold)]" : "border-[var(--line-strong)]"}`}>
                <input
                  type="checkbox"
                  className="h-5 w-5 accent-[#0a2342] shrink-0"
                  checked={checked.includes(c)}
                  onChange={() => setChecked(checked.includes(c) ? checked.filter((x) => x !== c) : [...checked, c])}
                />
                {c}
              </label>
            ))}
          </div>
        </div>
        <Field label="Notes for the owner">
          <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="How did it go? Anything the owner should know?" />
        </Field>
        <Field label="Issues, damage or maintenance">
          <Textarea rows={2} value={issues} onChange={(e) => setIssues(e.target.value)} placeholder="Leave blank if none" />
        </Field>
        <Field label="Supplies / restock needed">
          <Textarea rows={2} value={supplies} onChange={(e) => setSupplies(e.target.value)} placeholder="e.g. coffee pods, dish soap" />
        </Field>
        <div className="flex gap-3 justify-end">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={submit} disabled={busy}>
            {busy ? "Submitting…" : "Submit & complete job"}
          </Button>
        </div>
      </div>
    </Modal>
  );
}
