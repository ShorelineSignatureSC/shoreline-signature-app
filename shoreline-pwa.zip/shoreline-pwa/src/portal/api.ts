export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

let onUnauthorized: (() => void) | null = null;
export function setUnauthorizedHandler(fn: () => void) {
  onUnauthorized = fn;
}

export async function api<T = unknown>(path: string, opts: { method?: string; body?: unknown; raw?: BodyInit; contentType?: string } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  let body: BodyInit | undefined;
  if (opts.raw !== undefined) {
    body = opts.raw;
    if (opts.contentType) headers["Content-Type"] = opts.contentType;
  } else if (opts.body !== undefined) {
    body = JSON.stringify(opts.body);
    headers["Content-Type"] = "application/json";
  }
  const res = await fetch(path, { method: opts.method ?? (body ? "POST" : "GET"), headers, body, credentials: "same-origin" });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && onUnauthorized) onUnauthorized();
  if (!res.ok) throw new ApiError((data as { error?: string }).error || `Request failed (${res.status})`, res.status);
  return data as T;
}

export type Staff = {
  id: number;
  email: string;
  name: string;
  phone: string;
  role: "owner" | "employee";
  active: boolean;
  hasLogin?: boolean;
  protected?: boolean;
  jobsInRange?: number;
  jobsCompleted?: number;
};

export type Me = { id: number; name: string; email: string; phone: string; role: "owner" | "employee" };

export type Booking = {
  id: number;
  source?: string;
  requestType: "booking" | "quote";
  status: string;
  customerName: string;
  customerEmail?: string;
  customerPhone?: string;
  propertyAddress: string;
  propertyType: string;
  bedrooms: string;
  bathrooms: string;
  serviceType: string;
  addOns: string[];
  preferredDate: string | null;
  preferredTime: string;
  scheduledDate: string | null;
  scheduledTime: string;
  instructions: string;
  specialRequests: string;
  internalNotes?: string;
  price?: string;
  depositStatus?: string;
  startedAt: string | null;
  completedAt: string | null;
  createdAt?: string;
  updatedAt?: string;
  assigned?: { id: number; name: string }[];
};

export type Report = {
  id: number;
  checklist: string[];
  notes: string;
  issues: string;
  suppliesNeeded: string;
  reviewed: boolean;
  createdAt: string;
  staffName: string | null;
};

export type Photo = { id: number; kind: "before" | "after"; createdAt: string; staffId: number | null; staffName: string | null };

export type BookingDetail = {
  booking: Booking;
  assigned: { id: number; name: string }[];
  reports: Report[];
  photos: Photo[];
  events: { id: number; actor: string; action: string; createdAt: string }[];
};

export type Material = {
  id: number;
  title: string;
  category: string;
  kind: "text" | "file" | "link";
  description: string;
  body: string;
  externalUrl: string;
  fileName: string;
  contentType: string;
  fileSize: number;
  required: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  completedByMe: boolean;
  completions?: number;
};
