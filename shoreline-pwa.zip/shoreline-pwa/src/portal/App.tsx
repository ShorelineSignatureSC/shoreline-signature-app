import { useCallback, useEffect, useState } from "react";
import { getUser, handleAuthCallback, logout, onAuthChange } from "@netlify/identity";
import { BookOpen, CalendarDays, ClipboardList, Home, LogOut, Settings as SettingsIcon, UserCircle, Users, Briefcase } from "lucide-react";
import AuthScreen, { AuthShell, type AuthMode } from "./Auth";
import { api, ApiError, setUnauthorizedHandler, type Me } from "./api";
import { Button, Spinner, Toast } from "./ui";
import Overview from "./owner/Overview";
import Bookings from "./owner/Bookings";
import Team from "./owner/Team";
import Reports from "./owner/Reports";
import SettingsPage from "./owner/Settings";
import BookingPage from "./BookingPage";
import MyJobs from "./employee/MyJobs";
import Training from "./Training";
import Account from "./Account";

export type Ctx = { me: Me; toast: (m: string) => void; navigate: (path: string) => void };

type State =
  | { s: "loading" }
  | { s: "auth"; mode: AuthMode; token?: string; notice?: string }
  | { s: "denied"; message: string; email: string }
  | { s: "ready"; me: Me };

function useRoute() {
  const read = () => window.location.hash.replace(/^#/, "") || "/";
  const [route, setRoute] = useState(read);
  useEffect(() => {
    const on = () => setRoute(read());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const navigate = useCallback((p: string) => {
    window.location.hash = p;
    window.scrollTo({ top: 0 });
  }, []);
  return [route, navigate] as const;
}

export default function App() {
  const [state, setState] = useState<State>({ s: "loading" });
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [route, navigate] = useRoute();

  const toast = useCallback((m: string) => {
    setToastMsg(m);
    window.setTimeout(() => setToastMsg((cur) => (cur === m ? null : cur)), 3200);
  }, []);

  const loadMe = useCallback(async () => {
    const user = await getUser();
    if (!user) return setState({ s: "auth", mode: "login" });
    try {
      const { me } = await api<{ me: Me }>("/api/portal/me");
      setState({ s: "ready", me });
    } catch (e) {
      if (e instanceof ApiError && e.status === 403) setState({ s: "denied", message: e.message, email: user.email ?? "" });
      else if (e instanceof ApiError && e.status === 401) setState({ s: "auth", mode: "login" });
      else setState({ s: "denied", message: "We couldn’t load your portal. Please check your connection and try again.", email: user.email ?? "" });
    }
  }, []);

  useEffect(() => {
    setUnauthorizedHandler(() => setState({ s: "auth", mode: "login", notice: "Your session ended. Please sign in again." }));
    (async () => {
      try {
        const result = await handleAuthCallback();
        if (result) {
          history.replaceState(null, "", window.location.pathname);
          if (result.type === "invite" && result.token) return setState({ s: "auth", mode: "invite", token: result.token });
          if (result.type === "recovery") return setState({ s: "auth", mode: "reset" });
        }
      } catch {
        history.replaceState(null, "", window.location.pathname);
        setState({ s: "auth", mode: "login", notice: "That link has expired or was already used. Please sign in or request a new link." });
        return;
      }
      await loadMe();
    })();
    return onAuthChange((event) => {
      if (event === "logout") setState({ s: "auth", mode: "login" });
    });
  }, [loadMe]);

  const signOut = async () => {
    try {
      await logout();
    } catch {
      /* cookies are cleared regardless */
    }
    window.location.hash = "";
    setState({ s: "auth", mode: "login" });
  };

  if (state.s === "loading")
    return (
      <AuthShell>
        <div className="text-white">
          <Spinner label="Opening your portal…" />
        </div>
      </AuthShell>
    );
  if (state.s === "auth") return <AuthScreen key={state.mode + (state.notice ?? "")} initialMode={state.mode} inviteToken={state.token} notice={state.notice} onAuthed={loadMe} />;
  if (state.s === "denied")
    return (
      <AuthShell>
        <div className="w-full max-w-[440px] bg-[var(--surface)] text-[var(--ink)] p-8 border border-white/10">
          <h1 className="text-[24px]">Access not available</h1>
          <p className="mt-3 text-[14px] leading-[1.6] opacity-75">{state.message}</p>
          {state.email && <p className="mt-3 text-[12px] opacity-50">Signed in as {state.email}</p>}
          <div className="mt-6 flex gap-3">
            <Button onClick={loadMe}>Try again</Button>
            <Button variant="outline" onClick={signOut}>Sign out</Button>
          </div>
        </div>
      </AuthShell>
    );

  const me = state.me;
  const owner = me.role === "owner";
  const ctx: Ctx = { me, toast, navigate };

  const nav = owner
    ? [
        { path: "/", label: "Overview", icon: Home },
        { path: "/bookings", label: "Bookings", icon: CalendarDays },
        { path: "/team", label: "Team", icon: Users },
        { path: "/training", label: "Training", icon: BookOpen },
        { path: "/reports", label: "Reports", icon: ClipboardList },
        { path: "/settings", label: "Settings", icon: SettingsIcon },
      ]
    : [
        { path: "/", label: "My Jobs", icon: Briefcase },
        { path: "/training", label: "Training", icon: BookOpen },
        { path: "/account", label: "Account", icon: UserCircle },
      ];

  const seg = route.split("/").filter(Boolean);
  const activePath = seg[0] === "booking" ? (owner ? "/bookings" : "/") : "/" + (seg[0] ?? "");

  let page;
  if (seg[0] === "booking" && seg[1]) page = <BookingPage ctx={ctx} id={Number(seg[1])} />;
  else if (seg[0] === "training") page = <Training ctx={ctx} />;
  else if (seg[0] === "account") page = <Account ctx={ctx} onUpdated={(m) => setState({ s: "ready", me: m })} />;
  else if (owner && seg[0] === "bookings") page = <Bookings ctx={ctx} />;
  else if (owner && seg[0] === "team") page = <Team ctx={ctx} />;
  else if (owner && seg[0] === "reports") page = <Reports ctx={ctx} />;
  else if (owner && seg[0] === "settings") page = <SettingsPage ctx={ctx} />;
  else page = owner ? <Overview ctx={ctx} /> : <MyJobs ctx={ctx} />;

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--ink)] pb-24 lg:pb-0">
      <header className="sticky top-0 z-40 bg-[var(--navy)] text-white border-b-2 border-[var(--gold)]">
        <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-10 h-[60px] flex items-center justify-between gap-4">
          <a href="#/" className="flex items-center gap-3 min-w-0">
            <img src="/.netlify/images?url=/img/logo-emblem.png&w=76&h=76&fm=webp" alt="" aria-hidden="true" width={38} height={38} className="shrink-0 rounded-full ring-1 ring-[var(--gold)]" />
            <span className="leading-[0.95] min-w-0">
              <span className="block font-display font-[700] tracking-[0.2em] text-[15px]">SHORELINE</span>
              <span className="block font-[400] tracking-[0.2em] text-[10px] text-[var(--gold)]">{owner ? "OWNER PORTAL" : "TEAM PORTAL"}</span>
            </span>
          </a>
          <nav className="hidden lg:flex items-center gap-1" aria-label="Portal navigation">
            {nav.map((n) => (
              <a
                key={n.path}
                href={"#" + n.path}
                className={`h-9 px-3 flex items-center gap-2 text-[11px] tracking-[0.12em] uppercase font-semibold transition ${
                  activePath === n.path ? "bg-white/10 text-[var(--gold)]" : "text-white/75 hover:text-white"
                }`}
              >
                <n.icon size={14} /> {n.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-2 shrink-0">
            <a href="#/account" className="hidden sm:flex flex-col items-end leading-tight text-right hover:opacity-100 opacity-85">
              <span className="text-[12px] font-medium truncate max-w-[180px]">{me.name || me.email}</span>
              <span className="text-[10px] tracking-[0.14em] uppercase text-white/50">{owner ? "Owner / Admin" : "Employee"}</span>
            </a>
            <button onClick={signOut} className="h-9 px-3 border border-white/20 text-[11px] tracking-[0.12em] uppercase font-semibold flex items-center gap-1.5 hover:bg-white/10" aria-label="Sign out">
              <LogOut size={14} /> <span className="hidden sm:inline">Sign out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-10 py-6 sm:py-10">{page}</main>

      <nav
        className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-[var(--surface)] border-t border-[var(--line-strong)] grid"
        style={{ gridTemplateColumns: `repeat(${nav.length}, minmax(0,1fr))`, paddingBottom: "env(safe-area-inset-bottom)" }}
        aria-label="Portal navigation"
      >
        {nav.map((n) => (
          <a
            key={n.path}
            href={"#" + n.path}
            className={`h-16 flex flex-col items-center justify-center gap-1 text-[9px] tracking-[0.08em] uppercase font-semibold ${
              activePath === n.path ? "text-[var(--navy)] dark:text-[var(--gold)]" : "opacity-55"
            }`}
          >
            <n.icon size={19} className={activePath === n.path ? "text-[var(--gold)]" : ""} />
            {n.label}
          </a>
        ))}
      </nav>
      <Toast message={toastMsg} />
    </div>
  );
}
