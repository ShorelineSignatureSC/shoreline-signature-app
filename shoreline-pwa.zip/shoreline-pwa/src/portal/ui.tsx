import { useEffect, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes } from "react";
import { X, Loader2 } from "lucide-react";
import { BOOKING_STATUSES } from "../../shared/constants";

export function Button({
  variant = "primary",
  size = "md",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "gold" | "outline" | "ghost" | "danger"; size?: "sm" | "md" }) {
  const v = {
    primary: "bg-[var(--navy)] text-white hover:bg-[var(--navy-2)] dark:bg-[var(--gold)] dark:text-[#0a2342] dark:hover:bg-[#d6b67a]",
    gold: "bg-[var(--gold)] text-[#0a2342] hover:bg-[#d6b67a]",
    outline: "border border-[var(--line-strong)] hover:bg-[var(--surface-soft)]",
    ghost: "hover:bg-[var(--surface-soft)]",
    danger: "border border-red-300 text-red-700 hover:bg-red-50 dark:text-red-300 dark:border-red-800 dark:hover:bg-red-950/40",
  }[variant];
  const s = size === "sm" ? "h-9 px-3 text-[11px]" : "h-11 px-5 text-[12px]";
  return (
    <button
      {...props}
      className={`${s} ${v} tracking-[0.12em] uppercase font-semibold transition inline-flex items-center justify-center gap-2 disabled:opacity-50 ${className}`}
    />
  );
}

export const inputCls =
  "w-full h-11 px-3 border border-[var(--line-strong)] bg-[var(--surface)] text-[var(--ink)] focus:outline-none focus:border-[var(--navy)] dark:focus:border-[var(--gold)]";

export function Field({ label, children, hint, className = "" }: { label: string; children: ReactNode; hint?: string; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="text-[10px] tracking-[0.16em] uppercase opacity-60 font-medium">{label}</span>
      <div className="mt-1.5">{children}</div>
      {hint && <span className="block mt-1 text-[11px] opacity-50">{hint}</span>}
    </label>
  );
}

export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={`${inputCls} ${p.className ?? ""}`} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={`${inputCls} ${p.className ?? ""}`} />;
export const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => (
  <textarea {...p} className={`${inputCls} h-auto py-2.5 resize-y ${p.className ?? ""}`} />
);

const STATUS_STYLES: Record<string, string> = {
  pending: "border border-[var(--gold)] text-[var(--gold-dark)] bg-white",
  scheduled: "bg-[var(--sand-2)] text-[var(--navy)]",
  in_progress: "bg-[var(--gold)] text-[#0a2342]",
  completed: "bg-[var(--navy)] text-white",
  cancelled: "bg-[var(--sand)] text-[var(--ink-soft)] line-through",
};
export const STATUS_DOT: Record<string, string> = {
  pending: "bg-white ring-1 ring-[var(--gold)]",
  scheduled: "bg-[var(--navy)]/40",
  in_progress: "bg-[var(--gold)]",
  completed: "bg-[var(--navy)]",
  cancelled: "bg-[var(--sand-3)]",
};

export function StatusBadge({ status }: { status: string }) {
  const label = BOOKING_STATUSES.find((s) => s.value === status)?.label ?? status;
  return <span className={`inline-flex items-center px-2 py-0.5 text-[10px] tracking-[0.12em] uppercase font-semibold ${STATUS_STYLES[status] ?? ""}`}>{label}</span>;
}

export function Tag({ children, tone = "plain" }: { children: ReactNode; tone?: "plain" | "gold" | "navy" }) {
  const t = tone === "gold" ? "bg-[var(--gold)]/20 text-[#7d6433] dark:text-[var(--gold)]" : tone === "navy" ? "bg-[var(--navy)] text-white" : "bg-[var(--surface-soft)] border border-[var(--line)]";
  return <span className={`inline-flex items-center px-2 py-0.5 text-[10px] tracking-[0.12em] uppercase font-semibold ${t}`}>{children}</span>;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`bg-[var(--surface)] border border-[var(--line-strong)] ${className}`}>{children}</div>;
}

export function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div>
        {eyebrow && <div className="text-[10px] tracking-[0.22em] uppercase text-[var(--gold-dark)] dark:text-[var(--gold)] font-semibold">{eyebrow}</div>}
        <h1 className="mt-1 text-[28px] sm:text-[34px] leading-[1]">{title}</h1>
      </div>
      {action}
    </div>
  );
}

export function Spinner({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="py-16 flex items-center justify-center gap-3 text-[13px] opacity-60" role="status">
      <Loader2 size={18} className="animate-spin" /> {label}
    </div>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="py-14 px-6 text-center border border-dashed border-[var(--line-strong)]">
      <div className="font-display text-[20px]">{title}</div>
      {children && <div className="mt-2 text-[13px] opacity-60 max-w-[44ch] mx-auto">{children}</div>}
    </div>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  if (!children) return null;
  return (
    <div role="alert" className="px-4 py-3 border border-red-300 bg-red-50 text-red-800 text-[13px] dark:bg-red-950/40 dark:text-red-200 dark:border-red-800">
      {children}
    </div>
  );
}

export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center bg-[#050d1a]/60 backdrop-blur-sm" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={`bg-[var(--bg)] w-full ${wide ? "sm:max-w-[860px]" : "sm:max-w-[560px]"} max-h-[92vh] sm:max-h-[88vh] flex flex-col border border-[var(--line-strong)] shadow-2xl`}
      >
        <div className="flex items-center justify-between px-5 sm:px-6 h-14 border-b border-[var(--line-strong)] shrink-0">
          <h2 className="text-[20px]">{title}</h2>
          <button onClick={onClose} className="h-9 w-9 grid place-items-center hover:bg-[var(--surface-soft)]" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="overflow-y-auto p-5 sm:p-6">{children}</div>
      </div>
    </div>
  );
}

export function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-24 lg:bottom-6 left-1/2 -translate-x-1/2 z-[100] bg-[var(--navy)] text-white px-5 py-3 text-[13px] shadow-2xl border border-white/10" role="status">
      {message}
    </div>
  );
}
