import { useState, type FormEvent, type ReactNode } from "react";
import { AuthError, MissingIdentityError, acceptInvite, login, requestPasswordRecovery, signup, updateUser } from "@netlify/identity";
import { ArrowLeft, Lock } from "lucide-react";
import { Button, ErrorNote, Field, Input } from "./ui";

export type AuthMode = "login" | "signup" | "forgot" | "reset" | "invite";

function authMessage(err: unknown, mode: AuthMode) {
  if (err instanceof MissingIdentityError) return "Sign-in is temporarily unavailable. Please try again shortly.";
  if (err instanceof AuthError) {
    if (mode === "login" && (err.status === 400 || err.status === 401))
      return /confirm/i.test(err.message) ? "Please confirm your email first — check your inbox for the confirmation link." : "Incorrect email or password.";
    if (err.status === 401 || err.status === 403)
      return mode === "signup"
        ? "This email hasn’t been approved for portal access yet. Ask the owner to add you to the team first."
        : "That action isn’t allowed. Please contact the owner.";
    if (err.status === 422) return mode === "signup" ? "Please use a valid email and a password of at least 8 characters. If you already have an account, sign in instead." : err.message;
    return err.message || "Something went wrong.";
  }
  return "Something went wrong. Please try again.";
}

export function AuthShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[var(--navy)] text-white relative overflow-hidden flex flex-col">
      <div className="absolute inset-0 bg-gradient-to-br from-[#0A2342] via-[#0f2d55] to-[#16396a]" />
      <div
        className="absolute inset-0 opacity-40"
        style={{ background: "radial-gradient(800px 400px at 75% 20%, rgba(198,166,106,0.18), transparent 60%), radial-gradient(600px 300px at 10% 80%, rgba(237,230,214,0.12), transparent 60%)" }}
      />
      <header className="relative mx-auto w-full max-w-[1100px] px-6 h-[72px] flex items-center justify-between">
        <a href="/" className="flex items-center gap-3">
          <img src="/.netlify/images?url=/img/logo-emblem.png&w=88&h=88&fm=webp" alt="" aria-hidden="true" width={44} height={44} className="shrink-0 rounded-full ring-1 ring-[var(--gold)]" />
          <span className="leading-[0.95]">
            <span className="block font-display font-[700] tracking-[0.2em] text-[17px]">SHORELINE</span>
            <span className="block font-[500] tracking-[0.22em] text-[10px] text-[var(--gold)]">SIGNATURE SERVICES</span>
          </span>
        </a>
        <a href="/" className="text-[11px] tracking-[0.14em] uppercase opacity-70 hover:opacity-100 flex items-center gap-1.5">
          <ArrowLeft size={13} /> Website
        </a>
      </header>
      <main className="relative flex-1 grid place-items-center px-5 py-10">{children}</main>
    </div>
  );
}

export default function AuthScreen({
  initialMode = "login",
  inviteToken,
  notice,
  onAuthed,
}: {
  initialMode?: AuthMode;
  inviteToken?: string;
  notice?: string;
  onAuthed: () => void;
}) {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState(notice ?? "");

  const switchTo = (m: AuthMode) => {
    setMode(m);
    setError("");
    setInfo("");
  };

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");
    if ((mode === "signup" || mode === "reset" || mode === "invite") && password.length < 8) return setError("Password must be at least 8 characters.");
    if ((mode === "reset" || mode === "invite" || mode === "signup") && password !== password2) return setError("Passwords don’t match.");
    setBusy(true);
    try {
      if (mode === "login") {
        await login(email.trim(), password);
        onAuthed();
      } else if (mode === "signup") {
        const user = await signup(email.trim(), password, { full_name: name.trim() });
        if (user.confirmedAt) onAuthed();
        else {
          setMode("login");
          setPassword("");
          setPassword2("");
          setInfo("Account created. Check your email for a confirmation link, then sign in here.");
        }
      } else if (mode === "forgot") {
        await requestPasswordRecovery(email.trim());
        setInfo("If that email has a portal account, a password reset link is on its way.");
      } else if (mode === "reset") {
        await updateUser({ password });
        onAuthed();
      } else if (mode === "invite" && inviteToken) {
        await acceptInvite(inviteToken, password);
        onAuthed();
      }
    } catch (err) {
      setError(authMessage(err, mode));
    } finally {
      setBusy(false);
    }
  }

  const titles: Record<AuthMode, [string, string]> = {
    login: ["Team Portal", "Owner & employee sign in"],
    signup: ["Create your login", "For approved Shoreline team members"],
    forgot: ["Reset password", "We’ll email you a secure link"],
    reset: ["Choose a new password", "Finish resetting your password"],
    invite: ["Welcome to the team", "Set a password to activate your account"],
  };

  return (
    <AuthShell>
      <div className="w-full max-w-[420px]">
        <div className="bg-[var(--surface)] text-[var(--ink)] shadow-[0_32px_80px_-16px_rgba(0,0,0,0.5)] border border-white/10">
          <div className="p-7 sm:p-8">
            <img src="/.netlify/images?url=/img/logo-full.png&w=560&fm=webp" alt="Shoreline Signature Services" width={240} height={157} className="mx-auto mb-6 w-[220px] h-auto" />
            <div className="flex items-center gap-3 pt-5 border-t border-[var(--line)]">
              <div className="h-10 w-10 rounded-full bg-[var(--navy)] text-[var(--gold)] grid place-items-center">
                <Lock size={16} />
              </div>
              <div>
                <div className="text-[10px] tracking-[0.2em] uppercase opacity-50">{titles[mode][1]}</div>
                <h1 className="text-[24px] leading-[1.05]">{titles[mode][0]}</h1>
              </div>
            </div>
            <form onSubmit={submit} className="mt-7 space-y-4">
              {info && <div className="px-4 py-3 bg-[var(--gold)]/15 border border-[var(--gold)]/50 text-[13px]" role="status">{info}</div>}
              <ErrorNote>{error}</ErrorNote>
              {mode === "signup" && (
                <Field label="Full name">
                  <Input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required />
                </Field>
              )}
              {(mode === "login" || mode === "signup" || mode === "forgot") && (
                <Field label="Email">
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required autoFocus />
                </Field>
              )}
              {mode !== "forgot" && (
                <Field label={mode === "login" ? "Password" : "New password"}>
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete={mode === "login" ? "current-password" : "new-password"}
                    required
                    minLength={mode === "login" ? undefined : 8}
                  />
                </Field>
              )}
              {(mode === "signup" || mode === "reset" || mode === "invite") && (
                <Field label="Confirm password">
                  <Input type="password" value={password2} onChange={(e) => setPassword2(e.target.value)} autoComplete="new-password" required />
                </Field>
              )}
              <Button type="submit" disabled={busy} className="w-full">
                {busy
                  ? "Please wait…"
                  : { login: "Sign In", signup: "Create Account", forgot: "Send Reset Link", reset: "Save Password", invite: "Activate Account" }[mode]}
              </Button>
            </form>
            <div className="mt-6 pt-5 border-t border-[var(--line)] text-[12px] flex flex-wrap gap-x-4 gap-y-2 justify-between">
              {mode === "login" ? (
                <>
                  <button onClick={() => switchTo("forgot")} className="underline-offset-4 hover:underline opacity-70 hover:opacity-100">
                    Forgot password?
                  </button>
                  <button onClick={() => switchTo("signup")} className="underline-offset-4 hover:underline opacity-70 hover:opacity-100">
                    First time? Create your login
                  </button>
                </>
              ) : mode === "signup" || mode === "forgot" ? (
                <button onClick={() => switchTo("login")} className="underline-offset-4 hover:underline opacity-70 hover:opacity-100">
                  ← Back to sign in
                </button>
              ) : null}
            </div>
          </div>
          <div className="h-1 w-full bg-gradient-to-r from-[var(--gold)] to-[var(--navy)]" />
        </div>
        <p className="mt-5 text-center text-[11px] text-white/50 leading-[1.6]">
          Private area for Shoreline Signature Services owners and team members. {mode === "signup" && "Your email must be added by the owner before you can create a login."}
        </p>
      </div>
    </AuthShell>
  );
}
