import type { Config } from "@netlify/functions";
import { admin } from "@netlify/identity";
import { and, asc, desc, eq, gte, inArray, lte, or, sql, isNull } from "drizzle-orm";
import { db } from "../../db/index.js";
import {
  bookingAssignments,
  bookingEvents,
  bookings,
  jobPhotos,
  jobReports,
  staff,
  trainingCompletions,
  trainingMaterials,
} from "../../db/schema.js";
import {
  ADD_ONS,
  BEDROOM_OPTIONS,
  BOOKING_STATUSES,
  DEPOSIT_STATUSES,
  REPORT_CHECKLIST,
  TRAINING_CATEGORIES,
} from "../../shared/constants.js";
import { authenticate, fail, json, normalizeEmail, ownerEmails, type StaffRow } from "../lib/auth.js";
import { cleanSquareUrl, readSettings, writeSetting } from "../lib/settings.js";
import { TRAINING_CHUNK_SIZE, deleteTrainingFile, deletePhotoBlob } from "../lib/files.js";

type Booking = typeof bookings.$inferSelect;

const str = (v: unknown, max = 500) => String(v ?? "").trim().slice(0, max);
const isDate = (v: string) => /^\d{4}-\d{2}-\d{2}$/.test(v);
const STATUS_VALUES = BOOKING_STATUSES.map((s) => s.value) as string[];
const statusLabel = (v: string) => BOOKING_STATUSES.find((s) => s.value === v)?.label ?? v;

/** Fields employees may see. Customer contact details, pricing and owner notes stay owner-only. */
function forEmployee(b: Booking) {
  return {
    id: b.id,
    requestType: b.requestType,
    status: b.status,
    customerName: b.customerName,
    propertyAddress: b.propertyAddress,
    propertyType: b.propertyType,
    bedrooms: b.bedrooms,
    bathrooms: b.bathrooms,
    serviceType: b.serviceType,
    addOns: b.addOns,
    scheduledDate: b.scheduledDate,
    scheduledTime: b.scheduledTime,
    preferredDate: b.preferredDate,
    preferredTime: b.preferredTime,
    instructions: b.instructions,
    specialRequests: b.specialRequests,
    startedAt: b.startedAt,
    completedAt: b.completedAt,
  };
}

async function assignmentsFor(ids: number[]) {
  if (!ids.length) return new Map<number, { id: number; name: string }[]>();
  const rows = await db
    .select({ bookingId: bookingAssignments.bookingId, id: staff.id, name: staff.name, email: staff.email })
    .from(bookingAssignments)
    .innerJoin(staff, eq(staff.id, bookingAssignments.staffId))
    .where(inArray(bookingAssignments.bookingId, ids));
  const map = new Map<number, { id: number; name: string }[]>();
  for (const r of rows) {
    const list = map.get(r.bookingId) ?? [];
    list.push({ id: r.id, name: r.name || r.email });
    map.set(r.bookingId, list);
  }
  return map;
}

async function logEvent(bookingId: number, me: StaffRow, action: string) {
  await db.insert(bookingEvents).values({ bookingId, actor: me.name || me.email, action });
}

async function isAssigned(bookingId: number, staffId: number) {
  const [row] = await db
    .select({ b: bookingAssignments.bookingId })
    .from(bookingAssignments)
    .where(and(eq(bookingAssignments.bookingId, bookingId), eq(bookingAssignments.staffId, staffId)))
    .limit(1);
  return !!row;
}

function bookingInput(body: Record<string, unknown>, partial: boolean) {
  const v: Partial<typeof bookings.$inferInsert> = {};
  const set = <K extends keyof typeof bookings.$inferInsert>(k: K, val: (typeof bookings.$inferInsert)[K]) => {
    v[k] = val;
  };
  const has = (k: string) => !partial || k in body;
  if (has("customerName")) set("customerName", str(body.customerName, 120));
  if (has("customerEmail")) set("customerEmail", str(body.customerEmail, 200));
  if (has("customerPhone")) set("customerPhone", str(body.customerPhone, 40));
  if (has("propertyAddress")) set("propertyAddress", str(body.propertyAddress, 300));
  if (has("propertyType")) set("propertyType", str(body.propertyType, 60));
  if (has("bedrooms")) {
    const b = str(body.bedrooms, 10);
    set("bedrooms", BEDROOM_OPTIONS.some((o) => o.value === b) ? b : "");
  }
  if (has("bathrooms")) set("bathrooms", str(body.bathrooms, 20));
  if (has("serviceType")) set("serviceType", str(body.serviceType, 120));
  if (has("addOns"))
    set(
      "addOns",
      Array.isArray(body.addOns) ? body.addOns.map((a) => str(a, 80)).filter((a) => (ADD_ONS as readonly string[]).includes(a)) : [],
    );
  if (has("requestType")) set("requestType", body.requestType === "quote" ? "quote" : "booking");
  if (has("preferredDate")) {
    const d = str(body.preferredDate, 10);
    set("preferredDate", isDate(d) ? d : null);
  }
  if (has("preferredTime")) set("preferredTime", str(body.preferredTime, 40));
  if (has("scheduledDate")) {
    const d = str(body.scheduledDate, 10);
    set("scheduledDate", isDate(d) ? d : null);
  }
  if (has("scheduledTime")) set("scheduledTime", str(body.scheduledTime, 10));
  if (has("instructions")) set("instructions", str(body.instructions, 5000));
  if (has("specialRequests")) set("specialRequests", str(body.specialRequests, 5000));
  if (has("internalNotes")) set("internalNotes", str(body.internalNotes, 5000));
  if (has("price")) set("price", str(body.price, 80));
  if (has("depositStatus")) {
    const d = str(body.depositStatus, 20);
    set("depositStatus", DEPOSIT_STATUSES.some((s) => s.value === d) ? d : "none");
  }
  if (has("status")) {
    const s = str(body.status, 20);
    if (STATUS_VALUES.includes(s)) set("status", s);
  }
  return v;
}

async function setAssignments(bookingId: number, staffIds: unknown, me: StaffRow) {
  if (!Array.isArray(staffIds)) return;
  const wanted = [...new Set(staffIds.map(Number).filter((n) => Number.isInteger(n) && n > 0))];
  const valid = wanted.length
    ? (await db.select({ id: staff.id, name: staff.name, email: staff.email }).from(staff).where(inArray(staff.id, wanted)))
    : [];
  const current = await db.select({ staffId: bookingAssignments.staffId }).from(bookingAssignments).where(eq(bookingAssignments.bookingId, bookingId));
  const currentIds = new Set(current.map((c) => c.staffId));
  const validIds = new Set(valid.map((v) => v.id));
  const toRemove = [...currentIds].filter((id) => !validIds.has(id));
  const toAdd = valid.filter((v) => !currentIds.has(v.id));
  if (toRemove.length)
    await db.delete(bookingAssignments).where(and(eq(bookingAssignments.bookingId, bookingId), inArray(bookingAssignments.staffId, toRemove)));
  if (toAdd.length) await db.insert(bookingAssignments).values(toAdd.map((v) => ({ bookingId, staffId: v.id })));
  if (toAdd.length || toRemove.length) {
    const names = valid.map((v) => v.name || v.email);
    await logEvent(bookingId, me, names.length ? `Assigned to ${names.join(", ")}` : "All team assignments removed");
  }
}

async function bookingDetail(id: number, me: StaffRow) {
  const [b] = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
  if (!b) return null;
  const owner = me.role === "owner";
  if (!owner && !(await isAssigned(id, me.id))) return null;
  const assigned = (await assignmentsFor([id])).get(id) ?? [];
  const reports = await db
    .select({
      id: jobReports.id,
      checklist: jobReports.checklist,
      notes: jobReports.notes,
      issues: jobReports.issues,
      suppliesNeeded: jobReports.suppliesNeeded,
      reviewed: jobReports.reviewed,
      createdAt: jobReports.createdAt,
      staffName: staff.name,
    })
    .from(jobReports)
    .leftJoin(staff, eq(staff.id, jobReports.staffId))
    .where(eq(jobReports.bookingId, id))
    .orderBy(desc(jobReports.createdAt));
  const photos = await db
    .select({ id: jobPhotos.id, kind: jobPhotos.kind, createdAt: jobPhotos.createdAt, staffId: jobPhotos.staffId, staffName: staff.name })
    .from(jobPhotos)
    .leftJoin(staff, eq(staff.id, jobPhotos.staffId))
    .where(eq(jobPhotos.bookingId, id))
    .orderBy(asc(jobPhotos.createdAt));
  const events = owner
    ? await db.select().from(bookingEvents).where(eq(bookingEvents.bookingId, id)).orderBy(desc(bookingEvents.createdAt)).limit(100)
    : [];
  return { booking: owner ? b : forEmployee(b), assigned, reports, photos, events };
}

export default async (req: Request) => {
  const auth = await authenticate();
  if (!auth.ok) return fail(auth.status, auth.error);
  const me = auth.me;
  const owner = me.role === "owner";
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/portal\/?/, "").split("/").filter(Boolean);
  const method = req.method;
  const readBody = async (): Promise<Record<string, unknown>> => {
    try {
      const b = await req.json();
      return b && typeof b === "object" ? b : {};
    } catch {
      return {};
    }
  };
  const ownerOnly = () => fail(403, "Only owners can do that.");

  try {
    // ---------- Me ----------
    if (parts[0] === "me" && method === "GET") {
      return json({ me: { id: me.id, name: me.name, email: me.email, phone: me.phone, role: me.role } });
    }
    if (parts[0] === "me" && method === "PATCH") {
      const body = await readBody();
      const [row] = await db
        .update(staff)
        .set({ name: str(body.name, 120) || me.name, phone: str(body.phone, 40), updatedAt: new Date() })
        .where(eq(staff.id, me.id))
        .returning();
      return json({ me: { id: row.id, name: row.name, email: row.email, phone: row.phone, role: row.role } });
    }

    // ---------- Overview ----------
    if (parts[0] === "overview" && method === "GET") {
      const today = str(url.searchParams.get("today"), 10);
      if (!isDate(today)) return fail(400, "Missing date");
      if (owner) {
        const counts = await db.select({ status: bookings.status, n: sql<number>`count(*)::int` }).from(bookings).groupBy(bookings.status);
        const [todayCount] = await db
          .select({ n: sql<number>`count(*)::int` })
          .from(bookings)
          .where(and(eq(bookings.scheduledDate, today), sql`${bookings.status} <> 'cancelled'`));
        const [unassigned] = await db
          .select({ n: sql<number>`count(*)::int` })
          .from(bookings)
          .where(
            and(
              inArray(bookings.status, ["pending", "scheduled"]),
              sql`not exists (select 1 from booking_assignments a where a.booking_id = ${bookings.id})`,
            ),
          );
        const [unreviewed] = await db.select({ n: sql<number>`count(*)::int` }).from(jobReports).where(eq(jobReports.reviewed, false));
        return json({
          counts: Object.fromEntries(counts.map((c) => [c.status, c.n])),
          today: todayCount?.n ?? 0,
          unassigned: unassigned?.n ?? 0,
          unreviewedReports: unreviewed?.n ?? 0,
        });
      }
      return fail(404, "Not found");
    }

    // ---------- Bookings ----------
    if (parts[0] === "bookings") {
      const id = parts[1] ? Number(parts[1]) : null;
      if (id !== null && !Number.isInteger(id)) return fail(400, "Invalid booking");

      if (id === null && method === "GET") {
        const from = str(url.searchParams.get("from"), 10);
        const to = str(url.searchParams.get("to"), 10);
        const status = str(url.searchParams.get("status"), 20);
        const q = str(url.searchParams.get("q"), 100);
        const conds = [];
        const day = sql`coalesce(${bookings.scheduledDate}, ${bookings.preferredDate})`;
        if (isDate(from)) conds.push(sql`${day} >= ${from}`);
        if (isDate(to)) conds.push(sql`${day} <= ${to}`);
        if (status === "active") conds.push(inArray(bookings.status, ["pending", "scheduled", "in_progress"]));
        else if (status === "unscheduled") conds.push(isNull(bookings.scheduledDate), sql`${bookings.status} <> 'cancelled'`);
        else if (STATUS_VALUES.includes(status)) conds.push(eq(bookings.status, status));
        if (q) {
          const like = `%${q.replace(/[%_\\]/g, (m) => "\\" + m)}%`;
          conds.push(
            or(
              sql`${bookings.customerName} ilike ${like}`,
              sql`${bookings.propertyAddress} ilike ${like}`,
              sql`${bookings.customerEmail} ilike ${like}`,
              sql`${bookings.customerPhone} ilike ${like}`,
            )!,
          );
        }
        if (!owner) conds.push(sql`exists (select 1 from booking_assignments a where a.booking_id = ${bookings.id} and a.staff_id = ${me.id})`);
        if (!owner) conds.push(sql`${bookings.status} <> 'cancelled'`);
        const rows = await db
          .select()
          .from(bookings)
          .where(conds.length ? and(...conds) : undefined)
          .orderBy(sql`${day} asc nulls last`, asc(bookings.scheduledTime), desc(bookings.createdAt))
          .limit(500);
        const assign = await assignmentsFor(rows.map((r) => r.id));
        return json({
          bookings: rows.map((r) => ({ ...(owner ? r : forEmployee(r)), assigned: assign.get(r.id) ?? [] })),
        });
      }

      if (id === null && method === "POST") {
        if (!owner) return ownerOnly();
        const body = await readBody();
        const values = bookingInput(body, false);
        if (!values.customerName) return fail(422, "Customer name is required.");
        if (!values.status) values.status = values.scheduledDate ? "scheduled" : "pending";
        const [row] = await db
          .insert(bookings)
          .values({ ...(values as typeof bookings.$inferInsert), source: "portal" })
          .returning();
        await logEvent(row.id, me, "Booking created in portal");
        await setAssignments(row.id, body.staffIds, me);
        return json(await bookingDetail(row.id, me), 201);
      }

      if (id !== null && parts.length === 2 && method === "GET") {
        const detail = await bookingDetail(id, me);
        return detail ? json(detail) : fail(404, "Booking not found.");
      }

      if (id !== null && parts.length === 2 && method === "PATCH") {
        if (!owner) return ownerOnly();
        const [before] = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
        if (!before) return fail(404, "Booking not found.");
        const body = await readBody();
        const values = bookingInput(body, true);
        if ("customerName" in values && !values.customerName) return fail(422, "Customer name is required.");
        if (values.status === "completed" && !before.completedAt) values.completedAt = new Date();
        if (values.status === "in_progress" && !before.startedAt) values.startedAt = new Date();
        if (values.status && values.status !== "completed" && values.status !== before.status && before.status === "completed") values.completedAt = null;
        if (Object.keys(values).length) {
          await db.update(bookings).set({ ...values, updatedAt: new Date() }).where(eq(bookings.id, id));
          const changes: string[] = [];
          if (values.status && values.status !== before.status) changes.push(`Status changed to ${statusLabel(values.status)}`);
          if ("scheduledDate" in values && values.scheduledDate !== before.scheduledDate)
            changes.push(values.scheduledDate ? `Scheduled for ${values.scheduledDate}${values.scheduledTime ? " at " + values.scheduledTime : ""}` : "Schedule cleared");
          else if ("scheduledTime" in values && values.scheduledTime !== before.scheduledTime) changes.push(`Time set to ${values.scheduledTime || "TBD"}`);
          if ("depositStatus" in values && values.depositStatus !== before.depositStatus)
            changes.push(DEPOSIT_STATUSES.find((d) => d.value === values.depositStatus)?.label ?? "Deposit updated");
          const other = Object.keys(values).filter((k) => !["status", "scheduledDate", "scheduledTime", "depositStatus", "completedAt", "startedAt"].includes(k));
          if (other.some((k) => (values as Record<string, unknown>)[k] !== (before as Record<string, unknown>)[k] && JSON.stringify((values as Record<string, unknown>)[k]) !== JSON.stringify((before as Record<string, unknown>)[k])))
            changes.push("Booking details edited");
          for (const c of changes) await logEvent(id, me, c);
        }
        await setAssignments(id, body.staffIds, me);
        return json(await bookingDetail(id, me));
      }

      if (id !== null && parts.length === 2 && method === "DELETE") {
        if (!owner) return ownerOnly();
        const photos = await db.select({ key: jobPhotos.blobKey }).from(jobPhotos).where(eq(jobPhotos.bookingId, id));
        await db.delete(bookings).where(eq(bookings.id, id));
        await Promise.all(photos.map((p) => deletePhotoBlob(p.key)));
        return json({ ok: true });
      }

      // Job actions (owner or assigned employee)
      if (id !== null && parts[2] && method === "POST") {
        const [b] = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
        if (!b) return fail(404, "Booking not found.");
        if (!owner && !(await isAssigned(id, me.id))) return fail(403, "This job is not assigned to you.");
        if (b.status === "cancelled") return fail(409, "This booking was cancelled.");

        if (parts[2] === "start") {
          if (b.status === "completed") return fail(409, "This job is already completed.");
          await db.update(bookings).set({ status: "in_progress", startedAt: b.startedAt ?? new Date(), updatedAt: new Date() }).where(eq(bookings.id, id));
          if (b.status !== "in_progress") await logEvent(id, me, "Job started");
          return json(await bookingDetail(id, me));
        }

        if (parts[2] === "complete") {
          const body = await readBody();
          const checklist = Array.isArray(body.checklist)
            ? body.checklist.map((c) => str(c, 200)).filter((c) => (REPORT_CHECKLIST as readonly string[]).includes(c))
            : [];
          await db.insert(jobReports).values({
            bookingId: id,
            staffId: me.id,
            checklist,
            notes: str(body.notes, 5000),
            issues: str(body.issues, 5000),
            suppliesNeeded: str(body.suppliesNeeded, 2000),
          });
          await db
            .update(bookings)
            .set({ status: "completed", startedAt: b.startedAt ?? new Date(), completedAt: new Date(), updatedAt: new Date() })
            .where(eq(bookings.id, id));
          await logEvent(id, me, "Job completed — completion report submitted");
          return json(await bookingDetail(id, me));
        }
      }
      return fail(404, "Not found");
    }

    // ---------- Reports (owner) ----------
    if (parts[0] === "reports") {
      if (!owner) return ownerOnly();
      if (!parts[1] && method === "GET") {
        const filter = url.searchParams.get("filter");
        const rows = await db
          .select({
            id: jobReports.id,
            bookingId: jobReports.bookingId,
            checklist: jobReports.checklist,
            notes: jobReports.notes,
            issues: jobReports.issues,
            suppliesNeeded: jobReports.suppliesNeeded,
            reviewed: jobReports.reviewed,
            createdAt: jobReports.createdAt,
            staffName: staff.name,
            customerName: bookings.customerName,
            propertyAddress: bookings.propertyAddress,
            scheduledDate: bookings.scheduledDate,
          })
          .from(jobReports)
          .innerJoin(bookings, eq(bookings.id, jobReports.bookingId))
          .leftJoin(staff, eq(staff.id, jobReports.staffId))
          .where(filter === "unreviewed" ? eq(jobReports.reviewed, false) : undefined)
          .orderBy(desc(jobReports.createdAt))
          .limit(200);
        const ids = [...new Set(rows.map((r) => r.bookingId))];
        const photos = ids.length
          ? await db.select({ id: jobPhotos.id, bookingId: jobPhotos.bookingId, kind: jobPhotos.kind }).from(jobPhotos).where(inArray(jobPhotos.bookingId, ids))
          : [];
        return json({
          reports: rows.map((r) => ({ ...r, photos: photos.filter((p) => p.bookingId === r.bookingId) })),
        });
      }
      if (parts[1] && method === "PATCH") {
        const body = await readBody();
        await db.update(jobReports).set({ reviewed: !!body.reviewed }).where(eq(jobReports.id, Number(parts[1])));
        return json({ ok: true });
      }
      return fail(404, "Not found");
    }

    // ---------- Staff (owner) ----------
    if (parts[0] === "staff") {
      if (!parts[1] && method === "GET") {
        // Employees need names for nothing beyond themselves; only owners list the team.
        if (!owner) return ownerOnly();
        const rows = await db.select().from(staff).orderBy(desc(staff.active), asc(staff.role), asc(staff.name));
        const from = str(url.searchParams.get("from"), 10);
        const to = str(url.searchParams.get("to"), 10);
        let load: { staffId: number; n: number }[] = [];
        if (isDate(from) && isDate(to)) {
          load = await db
            .select({ staffId: bookingAssignments.staffId, n: sql<number>`count(*)::int` })
            .from(bookingAssignments)
            .innerJoin(bookings, eq(bookings.id, bookingAssignments.bookingId))
            .where(and(gte(bookings.scheduledDate, from), lte(bookings.scheduledDate, to), sql`${bookings.status} <> 'cancelled'`))
            .groupBy(bookingAssignments.staffId);
        }
        const completed = await db
          .select({ staffId: bookingAssignments.staffId, n: sql<number>`count(*)::int` })
          .from(bookingAssignments)
          .innerJoin(bookings, eq(bookings.id, bookingAssignments.bookingId))
          .where(eq(bookings.status, "completed"))
          .groupBy(bookingAssignments.staffId);
        const owners = ownerEmails();
        return json({
          staff: rows.map((r) => ({
            ...r,
            hasLogin: !!r.identityId,
            protected: owners.includes(r.email),
            jobsInRange: load.find((l) => l.staffId === r.id)?.n ?? 0,
            jobsCompleted: completed.find((l) => l.staffId === r.id)?.n ?? 0,
          })),
        });
      }
      if (!owner) return ownerOnly();
      if (!parts[1] && method === "POST") {
        const body = await readBody();
        const email = normalizeEmail(body.email);
        const name = str(body.name, 120);
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return fail(422, "Enter a valid email address.");
        if (!name) return fail(422, "Enter the team member's name.");
        const role = body.role === "owner" ? "owner" : "employee";
        const password = String(body.password ?? "");
        if (password && password.length < 8) return fail(422, "Temporary password must be at least 8 characters.");
        const [exists] = await db.select({ id: staff.id }).from(staff).where(eq(staff.email, email)).limit(1);
        if (exists) return fail(409, "A team member with that email already exists.");
        const [row] = await db.insert(staff).values({ email, name, phone: str(body.phone, 40), role }).returning();
        let loginCreated = false;
        let loginError = "";
        if (password) {
          try {
            const user = await admin.createUser({ email, password, data: { user_metadata: { full_name: name } } });
            await db.update(staff).set({ identityId: user.id }).where(eq(staff.id, row.id));
            loginCreated = true;
          } catch (e) {
            loginError =
              e instanceof Error && /exist|registered/i.test(e.message)
                ? "A login already exists for this email. They can sign in with their existing password."
                : "The team member was added, but the login could not be created. They can create their own account from the portal sign-in page.";
          }
        }
        return json({ ok: true, loginCreated, loginError }, 201);
      }
      if (parts[1] && method === "PATCH") {
        const sid = Number(parts[1]);
        const [target] = await db.select().from(staff).where(eq(staff.id, sid)).limit(1);
        if (!target) return fail(404, "Team member not found.");
        const body = await readBody();
        const isProtected = ownerEmails().includes(target.email);
        const updates: Partial<StaffRow> = { updatedAt: new Date() };
        if ("name" in body) updates.name = str(body.name, 120) || target.name;
        if ("phone" in body) updates.phone = str(body.phone, 40);
        if ("role" in body && !isProtected && target.id !== me.id) updates.role = body.role === "owner" ? "owner" : "employee";
        if ("active" in body && !isProtected && target.id !== me.id) updates.active = !!body.active;
        await db.update(staff).set(updates).where(eq(staff.id, sid));

        if (body.password) {
          const password = String(body.password);
          if (password.length < 8) return fail(422, "Password must be at least 8 characters.");
          try {
            if (target.identityId) {
              await admin.updateUser(target.identityId, { password });
            } else {
              const user = await admin.createUser({ email: target.email, password, data: { user_metadata: { full_name: target.name } } });
              await db.update(staff).set({ identityId: user.id }).where(eq(staff.id, sid));
            }
          } catch {
            return fail(502, "Profile saved, but the password could not be set. If they already created their own login, ask them to use “Forgot password”.");
          }
        }
        return json({ ok: true });
      }
      if (parts[1] && method === "DELETE") {
        const sid = Number(parts[1]);
        const [target] = await db.select().from(staff).where(eq(staff.id, sid)).limit(1);
        if (!target) return fail(404, "Team member not found.");
        if (target.id === me.id || ownerEmails().includes(target.email)) return fail(409, "This owner account cannot be removed.");
        if (target.identityId) {
          try {
            await admin.deleteUser(target.identityId);
          } catch {
            /* login may already be gone */
          }
        }
        await db.delete(staff).where(eq(staff.id, sid));
        return json({ ok: true });
      }
      return fail(404, "Not found");
    }

    // ---------- Training ----------
    if (parts[0] === "training") {
      const mid = parts[1] ? Number(parts[1]) : null;
      if (mid === null && method === "GET") {
        const rows = await db.select().from(trainingMaterials).orderBy(asc(trainingMaterials.category), desc(trainingMaterials.createdAt));
        const done = await db.select().from(trainingCompletions).where(owner ? undefined : eq(trainingCompletions.staffId, me.id));
        const activeEmployees = owner
          ? (await db.select({ n: sql<number>`count(*)::int` }).from(staff).where(and(eq(staff.active, true), eq(staff.role, "employee"))))[0]?.n ?? 0
          : 0;
        return json({
          materials: rows.map((r) => ({
            ...r,
            completedByMe: done.some((d) => d.materialId === r.id && d.staffId === me.id),
            completions: owner ? done.filter((d) => d.materialId === r.id).length : undefined,
          })),
          activeEmployees,
        });
      }
      if (mid !== null && parts[2] === "complete" && method === "POST") {
        const body = await readBody();
        if (body.done === false)
          await db.delete(trainingCompletions).where(and(eq(trainingCompletions.materialId, mid), eq(trainingCompletions.staffId, me.id)));
        else await db.insert(trainingCompletions).values({ materialId: mid, staffId: me.id }).onConflictDoNothing();
        return json({ ok: true });
      }
      if (!owner) return ownerOnly();
      const materialInput = (body: Record<string, unknown>) => {
        const category = (TRAINING_CATEGORIES as readonly string[]).includes(str(body.category)) ? str(body.category) : TRAINING_CATEGORIES[0];
        let externalUrl = str(body.externalUrl, 1000);
        if (externalUrl) {
          try {
            const u = new URL(externalUrl);
            if (!/^https?:$/.test(u.protocol)) externalUrl = "";
          } catch {
            externalUrl = "";
          }
        }
        return {
          title: str(body.title, 200),
          category,
          description: str(body.description, 2000),
          body: str(body.body, 50000),
          externalUrl,
          required: !!body.required,
        };
      };
      if (mid === null && method === "POST") {
        const body = await readBody();
        const v = materialInput(body);
        if (!v.title) return fail(422, "Please add a title.");
        const fileId = str(body.fileId, 80);
        const file =
          fileId && /^[a-f0-9-]{36}$/.test(fileId)
            ? {
                kind: "file",
                fileId,
                fileName: str(body.fileName, 200),
                contentType: str(body.contentType, 120) || "application/octet-stream",
                fileSize: Math.max(0, Number(body.fileSize) || 0),
                chunkSize: TRAINING_CHUNK_SIZE,
                chunkCount: Math.ceil(Math.max(0, Number(body.fileSize) || 0) / TRAINING_CHUNK_SIZE),
              }
            : { kind: v.externalUrl ? "link" : "text" };
        if (file.kind === "file" && !file.fileSize) return fail(422, "The uploaded file is empty.");
        if (file.kind === "text" && !v.body) return fail(422, "Add written instructions, a link, or a file.");
        const [row] = await db
          .insert(trainingMaterials)
          .values({ ...v, ...file, createdBy: me.name || me.email })
          .returning();
        return json({ material: row }, 201);
      }
      if (mid !== null && method === "PATCH") {
        const body = await readBody();
        const v = materialInput(body);
        if (!v.title) return fail(422, "Please add a title.");
        const [cur] = await db.select({ kind: trainingMaterials.kind }).from(trainingMaterials).where(eq(trainingMaterials.id, mid)).limit(1);
        if (!cur) return fail(404, "Not found");
        const kind = cur.kind === "file" ? "file" : v.externalUrl ? "link" : "text";
        if (kind === "text" && !v.body) return fail(422, "Add written instructions or a link.");
        const [row] = await db.update(trainingMaterials).set({ ...v, kind, updatedAt: new Date() }).where(eq(trainingMaterials.id, mid)).returning();
        return row ? json({ material: row }) : fail(404, "Not found");
      }
      if (mid !== null && method === "DELETE") {
        const [row] = await db.delete(trainingMaterials).where(eq(trainingMaterials.id, mid)).returning();
        if (row?.fileId) await deleteTrainingFile(row.fileId, row.chunkCount);
        return json({ ok: true });
      }
      return fail(404, "Not found");
    }

    // ---------- Settings (owner) ----------
    if (parts[0] === "settings") {
      if (!owner) return ownerOnly();
      if (method === "GET") return json(await readSettings());
      if (method === "PUT") {
        const body = await readBody();
        if ("squareUrl" in body) {
          const raw = str(body.squareUrl, 1000);
          const clean = cleanSquareUrl(raw);
          if (raw && !clean) return fail(422, "The deposit link must be a full https:// link (for example your Square checkout or booking link).");
          await writeSetting("squareUrl", clean);
        }
        if ("depositNote" in body) await writeSetting("depositNote", str(body.depositNote, 500));
        if (body.pricing && typeof body.pricing === "object") {
          const p: Record<string, string> = {};
          for (const b of BEDROOM_OPTIONS) p[b.value] = str((body.pricing as Record<string, unknown>)[b.value], 12).replace(/[^0-9.]/g, "");
          await writeSetting("pricing", p);
        }
        return json(await readSettings());
      }
    }

    return fail(404, "Not found");
  } catch (err) {
    console.error("portal-api error", url.pathname, err instanceof Error ? err.message : "unknown");
    return fail(500, "Something went wrong. Please try again.");
  }
};

export const config: Config = {
  path: ["/api/portal/*"],
};
