import type { Config } from "@netlify/functions";
import { db } from "../../db/index.js";
import { bookings, bookingEvents } from "../../db/schema.js";
import { ADD_ONS, BEDROOM_OPTIONS, DEFAULT_PRICING, PROPERTY_TYPES, SERVICE_TYPES } from "../../shared/constants.js";
import { readSettings } from "../lib/settings.js";
import { fail, json } from "../lib/auth.js";

const str = (v: unknown, max = 500) => String(v ?? "").trim().slice(0, max);
const isDate = (v: string) => /^\d{4}-\d{2}-\d{2}$/.test(v);

export default async (req: Request) => {
  const url = new URL(req.url);

  if (url.pathname === "/api/public/config" && req.method === "GET") {
    try {
      const s = await readSettings();
      return Response.json(s, { headers: { "Cache-Control": "public, max-age=60" } });
    } catch {
      return Response.json({ pricing: DEFAULT_PRICING, squareUrl: "", depositNote: "" }, { headers: { "Cache-Control": "no-store" } });
    }
  }

  if (url.pathname === "/api/public/booking-requests" && req.method === "POST") {
    let body: Record<string, unknown>;
    try {
      body = await req.json();
    } catch {
      return fail(400, "Invalid request.");
    }
    // Honeypot: real visitors never fill this field.
    if (str(body.company_website)) return json({ ok: true });

    const name = str(body.name, 120);
    const email = str(body.email, 200);
    const phone = str(body.phone, 40);
    const address = str(body.address, 300);
    const bedrooms = str(body.bedrooms, 10);
    const errors: string[] = [];
    if (!name) errors.push("Please enter your name.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push("Please enter a valid email address.");
    if (phone.replace(/\D/g, "").length < 7) errors.push("Please enter a valid phone number.");
    if (!address) errors.push("Please enter the property address.");
    const bedroomOpt = BEDROOM_OPTIONS.find((b) => b.value === bedrooms);
    if (!bedroomOpt) errors.push("Please choose the property bedroom count.");
    if (errors.length) return fail(422, errors.join(" "));

    const preferredDate = str(body.preferredDate, 10);
    const serviceType = (SERVICE_TYPES as readonly string[]).includes(str(body.serviceType)) ? str(body.serviceType) : SERVICE_TYPES[0];
    const propertyType = (PROPERTY_TYPES as readonly string[]).includes(str(body.propertyType)) ? str(body.propertyType) : "";
    const addOns = Array.isArray(body.addOns) ? body.addOns.map((a) => str(a, 80)).filter((a) => (ADD_ONS as readonly string[]).includes(a)) : [];
    const requestType = bedroomOpt!.quoteOnly || body.requestType === "quote" ? "quote" : "booking";

    const [row] = await db
      .insert(bookings)
      .values({
        source: "website",
        requestType,
        status: "pending",
        customerName: name,
        customerEmail: email,
        customerPhone: phone,
        propertyAddress: address,
        propertyType,
        bedrooms,
        bathrooms: str(body.bathrooms, 20),
        serviceType,
        addOns,
        preferredDate: isDate(preferredDate) ? preferredDate : null,
        preferredTime: str(body.preferredTime, 40),
        instructions: str(body.instructions, 3000),
        specialRequests: str(body.specialRequests, 3000),
      })
      .returning({ id: bookings.id });

    await db.insert(bookingEvents).values({
      bookingId: row.id,
      actor: "Customer",
      action: requestType === "quote" ? "Quote requested from website" : "Booking requested from website",
    });

    const s = await readSettings();
    return json({ ok: true, id: row.id, requestType, squareUrl: s.squareUrl, depositNote: s.depositNote }, 201);
  }

  return fail(404, "Not found");
};

export const config: Config = {
  path: ["/api/public/config", "/api/public/booking-requests"],
};
