import type { Config } from "@netlify/functions";
import { and, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { db } from "../../db/index.js";
import { bookingAssignments, bookingEvents, bookings, jobPhotos, trainingMaterials } from "../../db/schema.js";
import { authenticate, fail, json } from "../lib/auth.js";
import { MAX_TRAINING_FILE, TRAINING_CHUNK_SIZE, chunkKey, deletePhotoBlob, photoStore, trainingStore } from "../lib/files.js";

const MAX_PHOTO = 5 * 1024 * 1024;
const PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"];

async function canAccessBooking(bookingId: number, staffId: number, owner: boolean) {
  if (owner) return true;
  const [row] = await db
    .select({ b: bookingAssignments.bookingId })
    .from(bookingAssignments)
    .where(and(eq(bookingAssignments.bookingId, bookingId), eq(bookingAssignments.staffId, staffId)))
    .limit(1);
  return !!row;
}

export default async (req: Request) => {
  const auth = await authenticate();
  if (!auth.ok) return fail(auth.status, auth.error);
  const me = auth.me;
  const owner = me.role === "owner";
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/files\/?/, "").split("/").filter(Boolean);
  const method = req.method;

  try {
    // ---------- Job photos ----------
    // POST /api/files/photos/booking/:bookingId?kind=before|after   (raw image body)
    if (parts[0] === "photos" && parts[1] === "booking" && method === "POST") {
      const bookingId = Number(parts[2]);
      const [b] = await db.select({ id: bookings.id }).from(bookings).where(eq(bookings.id, bookingId)).limit(1);
      if (!b) return fail(404, "Booking not found.");
      if (!(await canAccessBooking(bookingId, me.id, owner))) return fail(403, "This job is not assigned to you.");
      const kind = url.searchParams.get("kind") === "before" ? "before" : "after";
      const contentType = (req.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
      if (!PHOTO_TYPES.includes(contentType)) return fail(415, "Please upload a JPG, PNG, WEBP or HEIC photo.");
      const data = await req.arrayBuffer();
      if (!data.byteLength) return fail(400, "Empty upload.");
      if (data.byteLength > MAX_PHOTO) return fail(413, "Photo is too large (5 MB max).");
      const key = `${bookingId}/${randomUUID()}`;
      await photoStore().set(key, data);
      const [row] = await db.insert(jobPhotos).values({ bookingId, staffId: me.id, kind, blobKey: key, contentType }).returning();
      await db.insert(bookingEvents).values({ bookingId, actor: me.name || me.email, action: `${kind === "before" ? "Before" : "After"} photo uploaded` });
      return json({ photo: { id: row.id, kind: row.kind, createdAt: row.createdAt, staffId: me.id, staffName: me.name } }, 201);
    }

    // GET/DELETE /api/files/photos/:photoId
    if (parts[0] === "photos" && parts[1] && parts[1] !== "booking") {
      const pid = Number(parts[1]);
      const [p] = await db.select().from(jobPhotos).where(eq(jobPhotos.id, pid)).limit(1);
      if (!p) return fail(404, "Photo not found.");
      if (!(await canAccessBooking(p.bookingId, me.id, owner))) return fail(403, "Not allowed.");
      if (method === "GET") {
        const data = await photoStore().get(p.blobKey, { type: "arrayBuffer" });
        if (!data) return fail(404, "Photo not found.");
        return new Response(data, { headers: { "Content-Type": p.contentType, "Cache-Control": "private, max-age=86400" } });
      }
      if (method === "DELETE") {
        if (!owner && p.staffId !== me.id) return fail(403, "You can only remove your own photos.");
        await db.delete(jobPhotos).where(eq(jobPhotos.id, pid));
        await deletePhotoBlob(p.blobKey);
        return json({ ok: true });
      }
    }

    // ---------- Training files ----------
    // POST /api/files/training/init  { size }  -> { fileId, chunkSize, chunkCount }
    if (parts[0] === "training" && parts[1] === "init" && method === "POST") {
      if (!owner) return fail(403, "Only owners can upload training materials.");
      const body = (await req.json().catch(() => ({}))) as { size?: number };
      const size = Number(body.size) || 0;
      if (size <= 0) return fail(400, "Empty file.");
      if (size > MAX_TRAINING_FILE) return fail(413, "Files must be 1 GB or smaller.");
      return json({ fileId: randomUUID(), chunkSize: TRAINING_CHUNK_SIZE, chunkCount: Math.ceil(size / TRAINING_CHUNK_SIZE) });
    }

    // PUT /api/files/training/upload/:fileId/:n   (raw chunk body)
    if (parts[0] === "training" && parts[1] === "upload" && method === "PUT") {
      if (!owner) return fail(403, "Only owners can upload training materials.");
      const fileId = parts[2] ?? "";
      const n = Number(parts[3]);
      if (!/^[a-f0-9-]{36}$/.test(fileId) || !Number.isInteger(n) || n < 0) return fail(400, "Invalid upload.");
      const data = await req.arrayBuffer();
      if (!data.byteLength || data.byteLength > TRAINING_CHUNK_SIZE) return fail(400, "Invalid chunk size.");
      await trainingStore().set(chunkKey(fileId, n), data);
      return json({ ok: true });
    }

    // GET /api/files/training/:materialId  (supports Range so videos can stream and seek)
    if (parts[0] === "training" && parts[1] && method === "GET") {
      const mid = Number(parts[1]);
      const [m] = await db.select().from(trainingMaterials).where(eq(trainingMaterials.id, mid)).limit(1);
      if (!m || !m.fileId || !m.chunkCount || !m.chunkSize) return fail(404, "File not found.");
      const store = trainingStore();
      const total = m.fileSize;
      const download = url.searchParams.get("download") === "1";
      const baseHeaders: Record<string, string> = {
        "Content-Type": m.contentType || "application/octet-stream",
        "Accept-Ranges": "bytes",
        "Cache-Control": "private, max-age=3600",
        "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${(m.fileName || "file").replace(/["\\\r\n]/g, "")}"`,
      };
      const range = req.headers.get("range");
      const match = range?.match(/^bytes=(\d*)-(\d*)$/);
      if (match && (match[1] || match[2])) {
        let start: number;
        let end: number;
        if (!match[1]) {
          start = Math.max(0, total - Number(match[2]));
          end = total - 1;
        } else {
          start = Number(match[1]);
          end = match[2] ? Math.min(Number(match[2]), total - 1) : total - 1;
        }
        if (start >= total || start > end) {
          return new Response(null, { status: 416, headers: { ...baseHeaders, "Content-Range": `bytes */${total}` } });
        }
        // Serve at most one stored chunk per request; players request the next range automatically.
        const idx = Math.floor(start / m.chunkSize);
        const chunkStart = idx * m.chunkSize;
        end = Math.min(end, chunkStart + m.chunkSize - 1);
        const chunk = await store.get(chunkKey(m.fileId, idx), { type: "arrayBuffer" });
        if (!chunk) return fail(404, "File data missing.");
        const slice = chunk.slice(start - chunkStart, end - chunkStart + 1);
        return new Response(slice, {
          status: 206,
          headers: { ...baseHeaders, "Content-Range": `bytes ${start}-${start + slice.byteLength - 1}/${total}`, "Content-Length": String(slice.byteLength) },
        });
      }
      // Full download: stream the stored chunks in order.
      const fileId = m.fileId;
      const count = m.chunkCount;
      let i = 0;
      const stream = new ReadableStream<Uint8Array>({
        async pull(controller) {
          if (i >= count) return controller.close();
          const chunk = await store.get(chunkKey(fileId, i++), { type: "arrayBuffer" });
          if (!chunk) return controller.error(new Error("missing chunk"));
          controller.enqueue(new Uint8Array(chunk));
        },
      });
      return new Response(stream, { headers: { ...baseHeaders, "Content-Length": String(total) } });
    }

    return fail(404, "Not found");
  } catch (err) {
    console.error("portal-files error", url.pathname, err instanceof Error ? err.message : "unknown");
    return fail(500, "Something went wrong. Please try again.");
  }
};

export const config: Config = {
  path: ["/api/files/*"],
};
