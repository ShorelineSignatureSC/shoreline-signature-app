import type { UserValidateEvent, UserSignupEvent } from "@netlify/functions";
import { isApprovedEmail } from "../lib/auth.js";

// Only the owner and team members the owner has added in the portal may create a login.
export default {
  async userValidate(event: UserValidateEvent) {
    if (!(await isApprovedEmail(event.user.email ?? ""))) return event.deny();
  },
  async userSignup(event: UserSignupEvent) {
    if (!(await isApprovedEmail(event.user.email ?? ""))) return event.deny();
  },
};
