import { eq, inArray } from "drizzle-orm";
import { db } from "../../db/index.js";
import { settings } from "../../db/schema.js";
import { DEFAULT_PRICING, type Pricing } from "../../shared/constants.js";

export type SiteSettings = { pricing: Pricing; squareUrl: string; depositNote: string };

const KEYS = ["pricing", "squareUrl", "depositNote"] as const;

export async function readSettings(): Promise<SiteSettings> {
  const rows = await db.select().from(settings).where(inArray(settings.key, [...KEYS]));
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  return {
    pricing: { ...DEFAULT_PRICING, ...((map.pricing as Pricing) ?? {}) },
    squareUrl: typeof map.squareUrl === "string" ? map.squareUrl : "",
    depositNote: typeof map.depositNote === "string" ? map.depositNote : "",
  };
}

export async function writeSetting(key: (typeof KEYS)[number], value: unknown) {
  const existing = await db.select({ key: settings.key }).from(settings).where(eq(settings.key, key));
  if (existing.length) await db.update(settings).set({ value, updatedAt: new Date() }).where(eq(settings.key, key));
  else await db.insert(settings).values({ key, value });
}

export function cleanSquareUrl(raw: unknown): string {
  const v = String(raw ?? "").trim();
  if (!v) return "";
  try {
    const u = new URL(v);
    if (u.protocol !== "https:") return "";
    return u.toString();
  } catch {
    return "";
  }
}
