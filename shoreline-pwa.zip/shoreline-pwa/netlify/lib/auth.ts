import { getUser } from "@netlify/identity";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { staff } from "../../db/schema.js";

export type StaffRow = typeof staff.$inferSelect;

/** Emails that always have owner/admin access. Configure with the OWNER_EMAILS environment variable (comma-separated). */
export function ownerEmails(): string[] {
  const raw = process.env.OWNER_EMAILS || "info@shorelinesignaturesc.com";
  return raw
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

export function normalizeEmail(e: unknown) {
  return String(e ?? "").trim().toLowerCase();
}

/** Is this email allowed to create/own a portal login? */
export async function isApprovedEmail(email: string) {
  const e = normalizeEmail(email);
  if (!e) return false;
  if (ownerEmails().includes(e)) return true;
  const [row] = await db.select({ id: staff.id, active: staff.active }).from(staff).where(eq(staff.email, e)).limit(1);
  return !!row?.active;
}

export type AuthResult =
  | { ok: true; me: StaffRow }
  | { ok: false; status: 401 | 403; error: string };

/** Resolves the signed-in Identity user to an active staff record. */
export async function authenticate(): Promise<AuthResult> {
  const user = await getUser();
  const email = normalizeEmail(user?.email);
  if (!user || !email) return { ok: false, status: 401, error: "Please sign in." };

  let [me] = await db.select().from(staff).where(eq(staff.email, email)).limit(1);
  const isBootstrapOwner = ownerEmails().includes(email);

  if (!me && isBootstrapOwner) {
    [me] = await db
      .insert(staff)
      .values({ email, name: user.name || "Owner", role: "owner", identityId: user.id })
      .onConflictDoNothing()
      .returning();
    if (!me) [me] = await db.select().from(staff).where(eq(staff.email, email)).limit(1);
  }
  if (!me) return { ok: false, status: 403, error: "This account has not been approved for portal access. Please contact the owner." };

  if (isBootstrapOwner && (me.role !== "owner" || !me.active)) {
    [me] = await db.update(staff).set({ role: "owner", active: true, updatedAt: new Date() }).where(eq(staff.id, me.id)).returning();
  }
  if (!me.active) return { ok: false, status: 403, error: "Your portal access has been deactivated. Please contact the owner." };

  if (!me.identityId) {
    await db.update(staff).set({ identityId: user.id }).where(eq(staff.id, me.id));
  }
  return { ok: true, me };
}

export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export function fail(status: number, error: string) {
  return json({ error }, status);
}
