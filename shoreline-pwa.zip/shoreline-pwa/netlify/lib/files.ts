import { getStore } from "@netlify/blobs";

export const TRAINING_CHUNK_SIZE = 3 * 1024 * 1024; // 3 MB per stored chunk keeps each request under function payload limits
export const MAX_TRAINING_FILE = 1024 * 1024 * 1024; // 1 GB

export const trainingStore = () => getStore("training-files");
export const photoStore = () => getStore("job-photos");

export const chunkKey = (fileId: string, n: number) => `${fileId}/${String(n).padStart(5, "0")}`;

export async function deleteTrainingFile(fileId: string, chunkCount: number) {
  const store = trainingStore();
  const keys = Array.from({ length: chunkCount }, (_, i) => chunkKey(fileId, i));
  await Promise.all(keys.map((k) => store.delete(k).catch(() => undefined)));
}

export async function deletePhotoBlob(key: string) {
  await photoStore()
    .delete(key)
    .catch(() => undefined);
}
