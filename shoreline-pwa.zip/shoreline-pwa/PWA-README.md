# Shoreline Signature Services — Phase 1 PWA

This is a copy of the supplied Netlify source project with an installable web app shell added. **The live website has not been changed.** Original images, logo, booking forms, server functions, database migrations and portal code remain intact.

## What changed
- Added a web app manifest, iPhone app metadata, and 192/512px app icons based on the existing Apple touch icon.
- Added a service worker and a public offline message. Portal pages, API requests, and payment data are deliberately **not cached**.
- Added worker registration to the existing home and portal entry points.

## Build and preview
1. Run `npm ci` then `npm run build` (requires Node.js and access to package dependencies).
2. Preview using `npm run dev` for the public site, or `netlify dev` for Netlify Functions and database integration.
3. Use a **separate Netlify preview/staging site** with its own configuration. Do not deploy to production until reviewed. The portal depends on Netlify Identity, database and configured environment.
4. On iPhone Safari, visit the tested HTTPS site, Share > Add to Home Screen > Add.

## Not yet implemented
Chase QuickAccept enrollment/integration, automatic 25%/75% payment splitting, additional customer portal workflows, end-to-end functional/security testing. These are not claimed to work.
